<?php
require "config.php";

date_default_timezone_set('Asia/Manila');
mysqli_report(MYSQLI_REPORT_OFF);

$conn = @mysqli_connect(SERVER_NAME, USERNAME, PASSWORD, DB_NAME);
if ($conn === false) {
    $dbError = mysqli_connect_error();
    error_log('Voting system database connection failed: ' . $dbError);
    http_response_code(503);
    $safeError = htmlspecialchars($dbError, ENT_QUOTES, 'UTF-8');
    echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Database unavailable - SBO Voting System</title>
    <style>
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #f5f6f4; color: #252a22; font: 16px/1.5 Arial, sans-serif; }
        main { box-sizing: border-box; width: min(92%, 560px); padding: 2rem; border: 1px solid #dee2dc; border-radius: 12px; background: #fff; box-shadow: 0 8px 28px #00000012; }
        h1 { margin-top: 0; color: #48672f; font-size: 1.5rem; }
        .error { overflow-wrap: anywhere; padding: .75rem; border-radius: 6px; background: #f8f9fa; color: #555; font-size: .9rem; }
    </style>
</head>
<body>
    <main>
        <h1>Database unavailable</h1>
        <p>The voting system cannot connect to its database right now. Start MySQL in the XAMPP Control Panel and try again.</p>
        <p>If MySQL is already running, check the database host, port, and credentials in <code>config.php</code>.</p>
        <p class="error">Connection details: ' . $safeError . '</p>
    </main>
</body>
</html>';
    exit;
}

// Force PHP and MySQL into the same timezone so date comparisons
// are always consistent regardless of the server environment
// Philippine Standard Time
$timezoneSet = mysqli_query($conn, "SET time_zone = '+08:00'");
if (!$timezoneSet) {
    $dbError = mysqli_error($conn);
    error_log('Voting system database timezone setup failed: ' . $dbError);
    http_response_code(503);
    mysqli_close($conn);
    exit('The voting system database is available, but its timezone could not be configured. Check the MySQL server configuration and try again.');
}
?>