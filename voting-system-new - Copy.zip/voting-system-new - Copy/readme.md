## Core Features
* **Secure Authentication:** Verifies voter identity and eligibility using official university email and passwords against campus records.
* **Ballot Management:** Provides administrators with CRUD (Create, Read, Update, Delete) capabilities to manage election rules, configuration parameters (start/end times, vote limits), and candidate lists.
* **Vote Processing & Validation:** Securely records cast ballots while enforcing a strict one-vote-per-user validation rule to prevent manipulation.
* **Automated Tallying:** Instantly calculates final election results once the polling period closes, eliminating human error.
* **Voter Verification:** Generates a downloadable or emailed confirmation receipt (JPG/Email) as verifiable evidence for the student that their ballot was submitted correctly, without revealing their specific choices.
* **Real-time Monitoring:** Features a live dashboard allowing moderators to track participation volume and detect irregularities in real time.

## System Actors
* **Student (Voter):** Authenticates via university ID to view available elections, cast ballots, and receive confirmation receipts.
* **Moderator:** Monitors voting activity in real-time to detect irregularities and provide system oversight.
* **Administrator:** Manages election events, candidates, and critical configuration parameters.

## Technology Stack
* **Backend:** PHP
* **Database:** MySQL
* **Access Environment:** Browser-based access for all students across colleges and departments

## Setup Instructions
1. Ensure you have a local server environment (like XAMPP or WAMP) running with PHP and MySQL.
2. Clone or place the project repository in your web server directory (e.g., `htdocs`).
3. Open `voting-system/config.php` and verify your MySQL credentials (`SERVER_NAME`, `USERNAME`, `PASSWORD`).
4. Navigate to `setup.php` in your web browser (e.g., `http://localhost/voting-system/setup.php`).
5. Click **Run Database Setup** to automatically generate the `db_voting_system` database alongside the `users` and `elections` tables.

## Voter and College Management
* Administrators can register colleges / departments from **View Users**. Registered colleges are available in voter registration, voter filters, and election setup. Existing department values are added to the college list automatically when the management pages are opened.
* Administrators can also manage these records from **Departments** in the sidebar. Renaming a department updates matching users and elections; deleting a department is blocked while users or elections are assigned to it.
* Closed elections can be declared complete by an administrator from **Reports**. Completed elections and their candidate winners/losers are displayed in **Results**; ties are co-winners, and a position with zero candidate votes has no winner.
* Admins can update system branding and support contact, default election duration, voter session timeout, minimum changed-password length, and first-login password-change requirement from **Settings**. The election duration prefills a closing time when creating an election; the session timeout controls stale-login detection.
* Students can open **Settings** from the Elections sidebar to change their password or submit a profile correction request. Requests do not change verified account data until an administrator approves them. Administrators review and approve or reject requests from **Profile Requests** in View Users; approvals update both the student account and matching voter registry record.
* Students can view final winners and vote totals for elections declared complete by an administrator from **Results** in the student sidebar.
* On **View Users**, admins can upload voter lists as `.csv` or `.xlsx` files. Required headers are `Student_id,firstname,lastname,email,department`; optional columns are `middlename` (or `middle_name`) and `year_level`. Headers are case-insensitive, and legacy `school_id` files remain supported. The XLSX importer reads the first worksheet with the header in row one. Format Student_id cells as text in Excel to preserve leading zeros. A row matching an existing student by Student_id or email updates that account and voter registry entry without changing its password; if those identifiers point to different accounts, the row is skipped and reported. The department must exactly match a registered college / department. Invalid emails, unregistered departments, and identity conflicts are skipped and reported.
* Imported voter data is saved in the dedicated `voters` table with matching spreadsheet fields and is also provisioned as a student login account in `users`. Existing student accounts are synchronized to the voter registry when **View Users** is opened; adding, editing, or deleting a student through that page also updates both records.
* Each imported voter receives the default password `123456` and is required to change it at first login. The password is stored as a hash.
* From **View Users**, admins can reset all student voter accounts to the default password `123456`. Only password hashes are stored. This action signs voters out and requires them to change the password at next login. Passwords changed through the application are also stored as hashes. Existing plaintext passwords are upgraded to hashes after a successful login.
* Admins can set or edit a student's year level on the user account. When a registered student is selected as a candidate, the ballot automatically displays the year level from that account.
* User and candidate names are collected and displayed as separate first, middle, and last name fields. Middle names are optional; for imported voters, omit the `middlename` column or leave its cells empty when unavailable.
* Existing candidate records from before name fields were added are split into a first name (the first word) and last name (the remaining words); no middle name is inferred from old full-name text.
* Administrators can search registered students by name, school ID, or email when adding candidates. Candidate name, school ID, and email are populated from the selected student record.
* Candidate registration includes a party-list name. On the student dashboard, voters open an election and then a position to see all its candidates together in side-by-side cards, with each candidate's party list labeled on their card. Voters select at most one candidate (or abstain) per position and submit their ballot from the dashboard; they do not vote for a whole slate.
