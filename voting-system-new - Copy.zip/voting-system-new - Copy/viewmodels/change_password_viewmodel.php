<?php
require '../connection.php';
include '../models/user.php';
require_once '../models/settings.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("location:login.php");
}

$message = "";
$minimumPasswordLength = 8;
if (!$conn || !ensureAppSettingsSchema($conn)) {
    $message = "Unable to load password settings. Please try again later.";
} else {
    $loadedMinimumLength = filter_var(getAppSetting($conn, 'minimum_password_length'), FILTER_VALIDATE_INT);
    if ($loadedMinimumLength === false || $loadedMinimumLength < 8 || $loadedMinimumLength > 64) {
        $message = "The configured minimum password length is invalid. Contact an administrator.";
    } else {
        $minimumPasswordLength = $loadedMinimumLength;
    }
}

if (isset($_POST['change_password']) && $message === '') {

    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $user_id = $_SESSION['user_id'];

    if (strlen($new_password) < $minimumPasswordLength) {
        $message = "Password must be at least {$minimumPasswordLength} characters long.";
    } elseif ($new_password === $confirm_password) {

        if (updateUserPassword($conn, $user_id, $new_password)) {

            // Password updated and is_new is 0. Redirect to the correct page.
            $role = $_SESSION['role'];
            if ($role == 'admin') {
                header("location:login.php");
                exit();
            } elseif ($role == 'moderator') {
                header("location:shared/dashboard.php");
                exit();
            } else {
                header("location:student/dashboard.php");
                exit();
            }
        } else {
            $message = "Database error: Could not update password.";
        }
    } else {
        $message = "Error: Passwords do not match. Please try again.";
    }
}
