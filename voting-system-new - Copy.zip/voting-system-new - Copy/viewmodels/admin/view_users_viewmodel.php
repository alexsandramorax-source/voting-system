<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("location: ../../index.php");
}

require '../../connection.php';
include '../../models/user.php';
include '../../models/college.php';
include '../../utils.php';

refreshActivity($conn, $_SESSION['user_id']);

$dbConnected = false;
$dbError = "";
$hasUsers = false;
$allUsers = [];
$allColleges = [];
$actionMessage = $_SESSION['user_action_message'] ?? "";
$actionType = $_SESSION['user_action_type'] ?? "success";
$importResults = $_SESSION['voter_import_results'] ?? null;
unset($_SESSION['user_action_message'], $_SESSION['user_action_type'], $_SESSION['voter_import_results']);

$admin_id = $_SESSION['user_id'];

if (!$conn || !ensureCollegeSchema($conn) || !ensureVoterRegistrySchema($conn)) {
    $dbError = $conn ? mysqli_error($conn) : mysqli_connect_error();
} else {
    $dbConnected = true;
    $allColleges = getColleges($conn);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $dbConnected) {
    if (isset($_POST['add_user'])) {
        $school_id = trim($_POST['school_id']);
        $firstname = trim($_POST['firstname']);
        $middlename = trim($_POST['middlename'] ?? '');
        $lastname = trim($_POST['lastname']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $role = in_array($_POST['role'] ?? '', ['student', 'moderator', 'admin'], true) ? $_POST['role'] : 'student';
        $department = trim($_POST['department']);
        $yearLevel = trim($_POST['year_level'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $actionMessage = "Enter a valid email address.";
            $actionType = "danger";
        } elseif ($firstname === '' || $lastname === '') {
            $actionMessage = "First and last names are required.";
            $actionType = "danger";
        } elseif (strlen($firstname) > 100 || strlen($lastname) > 100) {
            $actionMessage = "First and last names must be 100 characters or fewer.";
            $actionType = "danger";
        } elseif (strlen($middlename) > 100) {
            $actionMessage = "Middle name must be 100 characters or fewer.";
            $actionType = "danger";
        } elseif (strlen($yearLevel) > 30) {
            $actionMessage = "Year level must be 30 characters or fewer.";
            $actionType = "danger";
        } elseif (!isRegisteredCollege($conn, $department)) {
            $actionMessage = "Select a registered college / department.";
            $actionType = "danger";
        } elseif (addUser($conn, $school_id, $firstname, $middlename, $lastname, $email, $password, $role, $department, $yearLevel)) {
            $actionMessage = "User successfully added.";
        } else {
            $actionMessage = "Error adding user: " . mysqli_error($conn);
            $actionType = "danger";
        }
    }

    if (isset($_POST['edit_user'])) {
        $id = (int) $_POST['user_id'];
        $school_id = trim($_POST['school_id']);
        $firstname = trim($_POST['firstname']);
        $middlename = trim($_POST['middlename'] ?? '');
        $lastname = trim($_POST['lastname']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $role = in_array($_POST['role'] ?? '', ['student', 'moderator', 'admin'], true) ? $_POST['role'] : 'student';
        $department = trim($_POST['department']);
        $yearLevel = trim($_POST['year_level'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $actionMessage = "Enter a valid email address.";
            $actionType = "danger";
        } elseif ($firstname === '' || $lastname === '') {
            $actionMessage = "First and last names are required.";
            $actionType = "danger";
        } elseif (strlen($firstname) > 100 || strlen($lastname) > 100) {
            $actionMessage = "First and last names must be 100 characters or fewer.";
            $actionType = "danger";
        } elseif (strlen($middlename) > 100) {
            $actionMessage = "Middle name must be 100 characters or fewer.";
            $actionType = "danger";
        } elseif (strlen($yearLevel) > 30) {
            $actionMessage = "Year level must be 30 characters or fewer.";
            $actionType = "danger";
        } elseif (!isRegisteredCollege($conn, $department)) {
            $actionMessage = "Select a registered college / department.";
            $actionType = "danger";
        } elseif (updateUser($conn, $id, $school_id, $firstname, $middlename, $lastname, $email, $password, $role, $department, $yearLevel)) {
            $actionMessage = "User successfully updated.";
        } else {
            $actionMessage = "Error updating user: " . mysqli_error($conn);
            $actionType = "danger";
        }
    }

    if (isset($_POST['add_college'])) {
        $collegeName = trim($_POST['college_name'] ?? '');
        $collegeCode = strtoupper(trim($_POST['college_code'] ?? ''));
        if ($collegeName !== '' && addCollege($conn, $collegeName, $collegeCode)) {
            $actionMessage = "College / department registered successfully.";
        } else {
            $actionMessage = "Unable to register college / department: " . mysqli_error($conn);
            $actionType = "danger";
        }
    }

    if (isset($_POST['generate_voter_passwords'])) {
        $passwordResults = generateDefaultPasswordsForVoters($conn);
        if (isset($passwordResults['error'])) {
            $actionMessage = $passwordResults['error'];
            $actionType = "danger";
        } elseif ($passwordResults['generated_count'] === 0) {
            $actionMessage = "There are no student voter accounts to generate passwords for.";
            $actionType = "warning";
            $importResults = null;
        } else {
            $importResults = $passwordResults;
            $actionMessage = "Reset {$passwordResults['generated_count']} voter account(s) to the default password 123456. All voter sessions were signed out, and each voter must change their password at next login.";
        }
    }

    if (isset($_POST['import_voters'])) {
        if (!isset($_FILES['voter_csv']) || $_FILES['voter_csv']['error'] !== UPLOAD_ERR_OK) {
            $actionMessage = "Please choose a valid .csv or .xlsx voter list.";
            $actionType = "danger";
        } else {
            $importResults = importVotersFromCsv(
                $conn,
                $_FILES['voter_csv']['tmp_name'],
                getColleges($conn),
                $_FILES['voter_csv']['name']
            );
            if (isset($importResults['error'])) {
                $actionMessage = $importResults['error'];
                $actionType = "danger";
                $importResults = null;
            } else {
                $addedCount = $importResults['added_count'];
                $updatedCount = $importResults['updated_count'];
                $actionParts = [];
                if ($addedCount > 0) {
                    $actionParts[] = "$addedCount new voter(s) imported";
                }
                if ($updatedCount > 0) {
                    $actionParts[] = "$updatedCount existing voter record(s) updated";
                }
                if ($actionParts === []) {
                    $actionMessage = "No voter records were imported or updated.";
                    $actionType = "warning";
                } else {
                    $actionMessage = implode('; ', $actionParts) . '.';
                    if ($addedCount > 0) {
                        $actionMessage .= ' The default password for new accounts is 123456; each voter must change it at first login.';
                    } elseif ($updatedCount > 0) {
                        $actionMessage .= ' Existing passwords were not changed.';
                    }
                    if (!empty($importResults['errors'])) {
                        $actionType = "warning";
                    }
                }
            }
        }
    }

    if (isset($_POST['delete_user'])) {
        $id = (int) $_POST['user_id'];

        if (deleteUser($conn, $id)) {
            $actionMessage = "User successfully deleted.";
        } else {
            $actionMessage = "Error deleting user: " . mysqli_error($conn);
            $actionType = "danger";
        }
    }

    $_SESSION['user_action_message'] = $actionMessage;
    $_SESSION['user_action_type'] = $actionType;
    if (isset($importResults) && !isset($importResults['error'])) {
        $_SESSION['voter_import_results'] = $importResults;
    }
    header("Location: view_users.php");
    exit();
}

if ($dbConnected) {
    $allUsers = getUserAll($conn, $_SESSION['user_id']);
    $hasUsers = !empty($allUsers);
    $voterRegistry = getVoterRegistry($conn);
    if ($voterRegistry === false) {
        $dbConnected = false;
        $dbError = mysqli_error($conn);
    }
} else {
    $voterRegistry = [];
}