<?php
session_start();

if (!isset($_SESSION['role'], $_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../index.php');
    exit;
}

require '../../connection.php';
require_once '../../models/college.php';
require_once '../../models/user.php';
require_once '../../models/profile_correction_request.php';
require_once '../../utils.php';

$requests = [];
$dbError = '';
$message = $_SESSION['profile_requests_message'] ?? '';
$messageType = $_SESSION['profile_requests_message_type'] ?? 'success';
unset($_SESSION['profile_requests_message'], $_SESSION['profile_requests_message_type']);
$csrfToken = $_SESSION['profile_requests_csrf'] ??= bin2hex(random_bytes(32));

if (!$conn) {
    $dbError = mysqli_connect_error();
} elseif (!ensureCollegeSchema($conn)
    || !ensureVoterRegistrySchema($conn)
    || !ensureProfileCorrectionRequestSchema($conn)) {
    $dbError = mysqli_error($conn);
} else {
    refreshActivity($conn, (int) $_SESSION['user_id']);
    $requests = getProfileCorrectionRequests($conn);
    if ($requests === false) {
        $requests = [];
        $dbError = mysqli_error($conn);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $dbError === '') {
    $submittedToken = $_POST['csrf_token'] ?? '';
    $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT);
    $decision = $_POST['decision'] ?? '';
    $reviewError = '';
    if (!is_string($submittedToken) || !hash_equals($csrfToken, $submittedToken)) {
        $message = 'Your form session expired. Please try again.';
        $messageType = 'danger';
    } elseif ($requestId === false || $requestId < 1 || !in_array($decision, ['approved', 'rejected'], true)) {
        $message = 'Select a valid profile correction request and action.';
        $messageType = 'danger';
    } elseif ($decision === 'approved') {
        $requestToApprove = null;
        foreach ($requests as $request) {
            if ((int) $request['id'] === $requestId) {
                $requestToApprove = $request;
                break;
            }
        }
        if (!$requestToApprove || !isRegisteredCollege($conn, $requestToApprove['requested_department'])) {
            $message = 'The requested department is no longer registered. Keep this request pending and contact the student.';
            $messageType = 'danger';
        } elseif (!reviewProfileCorrectionRequest($conn, $requestId, (int) $_SESSION['user_id'], $decision, $reviewError)) {
            $message = 'Unable to approve this request: ' . $reviewError;
            $messageType = 'danger';
        } else {
            $message = 'Profile correction approved and the student and voter records were updated.';
        }
    } elseif (!reviewProfileCorrectionRequest($conn, $requestId, (int) $_SESSION['user_id'], $decision, $reviewError)) {
        $message = 'Unable to reject this request: ' . $reviewError;
        $messageType = 'danger';
    } else {
        $message = 'Profile correction request rejected.';
    }

    $_SESSION['profile_requests_message'] = $message;
    $_SESSION['profile_requests_message_type'] = $messageType;
    header('Location: profile_correction_requests.php');
    exit;
}
