<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}

require '../../connection.php';
require_once '../../models/college.php';
require_once '../../models/user.php';
require_once '../../utils.php';

refreshActivity($conn, $_SESSION['user_id']);

$actionMessage = $_SESSION['department_action_message'] ?? '';
$actionType = $_SESSION['department_action_type'] ?? 'success';
unset($_SESSION['department_action_message'], $_SESSION['department_action_type']);
$allDepartments = [];
$dbError = '';

if (!ensureCollegeSchema($conn)) {
    $dbError = mysqli_error($conn);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actionMessage = '';
    $actionType = 'danger';

    if (isset($_POST['add_department'])) {
        $name = trim($_POST['department_name'] ?? '');
        $code = strtoupper(trim($_POST['department_code'] ?? ''));
        if ($name === '' || strlen($name) > 100 || strlen($code) > 30) {
            $actionMessage = 'Enter a department name up to 100 characters and an optional code up to 30 characters.';
        } elseif (addCollege($conn, $name, $code)) {
            $actionMessage = 'Department added successfully.';
            $actionType = 'success';
        } else {
            $actionMessage = 'Unable to add department: ' . mysqli_error($conn);
        }
    } elseif (isset($_POST['edit_department'])) {
        $id = filter_var($_POST['department_id'] ?? null, FILTER_VALIDATE_INT);
        $name = trim($_POST['department_name'] ?? '');
        $code = strtoupper(trim($_POST['department_code'] ?? ''));
        if ($id === false || $id < 1 || $name === '' || strlen($name) > 100 || strlen($code) > 30) {
            $actionMessage = 'Enter a valid department, name, and optional code.';
        } elseif (updateCollege($conn, $id, $name, $code)) {
            $actionMessage = 'Department updated successfully. Assigned users and elections were updated with its new name.';
            $actionType = 'success';
        } else {
            $actionMessage = 'Unable to update department: ' . mysqli_error($conn);
        }
    } elseif (isset($_POST['delete_department'])) {
        $id = filter_var($_POST['department_id'] ?? null, FILTER_VALIDATE_INT);
        if ($id === false || $id < 1) {
            $actionMessage = 'Select a valid department to delete.';
        } else {
            $result = deleteCollege($conn, $id);
            $actionMessage = $result['message'];
            $actionType = $result['success'] ? 'success' : 'danger';
        }
    }

    $_SESSION['department_action_message'] = $actionMessage;
    $_SESSION['department_action_type'] = $actionType;
    header('Location: view_departments.php');
    exit();
}

if ($dbError === '') {
    $allDepartments = getCollegesWithUsage($conn);
    if ($allDepartments === [] && mysqli_errno($conn) !== 0) {
        $dbError = mysqli_error($conn);
    }
}
