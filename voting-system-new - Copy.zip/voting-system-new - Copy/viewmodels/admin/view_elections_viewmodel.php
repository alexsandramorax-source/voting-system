<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../index.php");
}

require '../../connection.php';
include '../../models/election.php';
include '../../models/user.php';
include '../../models/college.php';
require_once '../../models/settings.php';
include '../../utils.php';


refreshActivity($conn, $_SESSION['user_id']);

$message = "";
$dbConnected = false;
$dbError = "";
$hasElections = false;
$allElections = [];
$filteredElections = [];
$allColleges = [];
$defaultElectionDurationHours = 24;
$requestedElectionStatus = $_GET['status'] ?? 'all';
$electionStatusFilter = is_string($requestedElectionStatus)
    && in_array($requestedElectionStatus, ['all', 'ongoing', 'upcoming', 'closed'], true)
    ? $requestedElectionStatus
    : 'all';

$admin_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['create_election'])) {
        $name = trim($_POST['election_name']);
        $department = trim($_POST['department']);

        // Convert datetime-local value (YYYY-MM-DDTHH:MM) to MySQL DATETIME format
        $open_at = str_replace('T', ' ', $_POST['open_at'])  . ':00';
        $close_at = str_replace('T', ' ', $_POST['close_at']) . ':00';

        if ($department !== 'University Wide' && !isRegisteredCollege($conn, $department)) {
            $message = "Select a registered college / department.";
        } elseif (createElection($conn, $name, $department, $open_at, $close_at)) {
            $message = "Election '$name' has been successfully created!";
            header("location:view_elections.php?success_msg={$message}");
        } else {
            $message = "Error creating election: " . mysqli_error($conn);
        }
    }

    if (isset($_POST['edit_election'])) {
        $id = (int) $_POST['election_id'];
        $name = trim($_POST['election_name']);
        $department = trim($_POST['department']);
        $open_at = str_replace('T', ' ', $_POST['open_at'])  . ':00';
        $close_at = str_replace('T', ' ', $_POST['close_at']) . ':00';

        if ($department !== 'University Wide' && !isRegisteredCollege($conn, $department)) {
            $message = "Select a registered college / department.";
        } elseif (updateElection($conn, $id, $name, $department, $open_at, $close_at)) {
            $message = "Election '$name' has been successfully updated!";
            header("location:view_elections.php?success_msg={$message}");
        } else {
            $message = "Error updating election: " . mysqli_error($conn);
        }
    }

    if (isset($_POST['close_election'])) {
        $id = (int) $_POST['election_id'];

        if (closeElection($conn, $id)) {
            $message = "The election has been closed early.";
            header("location:view_elections.php?success_msg={$message}");
        } else {
            $message = "Error closing election: " . mysqli_error($conn);
        }
    }

    if (isset($_POST['delete_election'])) {
        $id = (int) $_POST['election_id'];

        if (deleteElection($conn, $id)) {
            $message = "Election record has been permanently deleted.";
            header("location:view_elections.php?success_msg={$message}");
        } else {
            $message = "Error deleting election: " . mysqli_error($conn);
        }
    }

    header("Location: view_elections.php");
}

if ($conn) {
    $dbConnected = true;
    if (!ensureCollegeSchema($conn) || !ensureAppSettingsSchema($conn)) {
        $dbConnected = false;
        $dbError = mysqli_error($conn);
    } else {
        $allColleges = getColleges($conn);
        $allElections = getAllElections($conn);
        $settings = getAppSettings($conn);
        if ($settings === false) {
            $dbConnected = false;
            $dbError = mysqli_error($conn);
        } else {
            $defaultElectionDurationHours = (int) $settings['default_election_duration_hours'];
        }
        $filteredElections = array_values(array_filter($allElections, function ($election) use ($electionStatusFilter) {
            return $electionStatusFilter === 'all' || $election['status'] === $electionStatusFilter;
        }));
    }

    if (!empty($allElections)) {
        $hasElections = true;
    }
} else {
    $dbError = mysqli_connect_error();
}