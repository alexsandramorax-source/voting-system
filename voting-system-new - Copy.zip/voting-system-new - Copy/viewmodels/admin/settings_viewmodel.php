<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../index.php');
    exit;
}

require '../../connection.php';
require_once '../../models/settings.php';
require_once '../../models/user.php';
require_once '../../utils.php';

if ($conn) {
    refreshActivity($conn, $_SESSION['user_id']);
}

$dbError = '';
$settingsMessage = $_SESSION['settings_message'] ?? '';
$settingsMessageType = $_SESSION['settings_message_type'] ?? 'success';
unset($_SESSION['settings_message'], $_SESSION['settings_message_type']);
$appSettings = getDefaultAppSettings();

if (!$conn) {
    $dbError = mysqli_connect_error();
} elseif (!ensureAppSettingsSchema($conn)) {
    $dbError = mysqli_error($conn);
} else {
    $loadedSettings = getAppSettings($conn);
    if ($loadedSettings === false) {
        $dbError = mysqli_error($conn);
    } else {
        $appSettings = $loadedSettings;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $dbError === '') {
    $systemName = trim($_POST['system_name'] ?? '');
    $institutionName = trim($_POST['institution_name'] ?? '');
    $supportEmail = trim($_POST['support_email'] ?? '');
    $duration = filter_var($_POST['default_election_duration_hours'] ?? null, FILTER_VALIDATE_INT);
    $timeout = filter_var($_POST['session_timeout_minutes'] ?? null, FILTER_VALIDATE_INT);
    $minimumPasswordLength = filter_var($_POST['minimum_password_length'] ?? null, FILTER_VALIDATE_INT);
    $requirePasswordChange = ($_POST['require_password_change'] ?? '') === '1' ? '1' : '0';

    if ($systemName === '' || strlen($systemName) > 100 || $institutionName === '' || strlen($institutionName) > 100) {
        $settingsMessage = 'System and institution names are required and must not exceed 100 characters.';
        $settingsMessageType = 'danger';
    } elseif (strlen($supportEmail) > 100 || ($supportEmail !== '' && !filter_var($supportEmail, FILTER_VALIDATE_EMAIL))) {
        $settingsMessage = 'Enter a valid support email address of 100 characters or fewer, or leave it blank.';
        $settingsMessageType = 'danger';
    } elseif ($duration === false || $duration < 1 || $duration > 720) {
        $settingsMessage = 'Default election duration must be between 1 and 720 hours.';
        $settingsMessageType = 'danger';
    } elseif ($timeout === false || $timeout < 5 || $timeout > 1440) {
        $settingsMessage = 'Session timeout must be between 5 and 1440 minutes.';
        $settingsMessageType = 'danger';
    } elseif ($minimumPasswordLength === false || $minimumPasswordLength < 8 || $minimumPasswordLength > 64) {
        $settingsMessage = 'Minimum password length must be between 8 and 64 characters.';
        $settingsMessageType = 'danger';
    } else {
        $appSettings = [
            'system_name' => $systemName,
            'institution_name' => $institutionName,
            'support_email' => $supportEmail,
            'default_election_duration_hours' => (string) $duration,
            'session_timeout_minutes' => (string) $timeout,
            'minimum_password_length' => (string) $minimumPasswordLength,
            'require_password_change' => $requirePasswordChange
        ];
        if (saveAppSettings($conn, $appSettings)) {
            $settingsMessage = 'Settings saved successfully.';
            $settingsMessageType = 'success';
        } else {
            $settingsMessage = 'Unable to save settings: ' . mysqli_error($conn);
            $settingsMessageType = 'danger';
        }
    }

    $_SESSION['settings_message'] = $settingsMessage;
    $_SESSION['settings_message_type'] = $settingsMessageType;
    header('Location: settings.php');
    exit;
}
