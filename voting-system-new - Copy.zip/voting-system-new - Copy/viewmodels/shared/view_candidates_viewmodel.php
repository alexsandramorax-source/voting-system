<?php
session_start();

// Both admin and moderator can manage candidates
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'moderator'])) {
    header("Location: ../../index.php");
}

require '../../connection.php';
include '../../models/candidate.php';
include '../../models/election.php';
include '../../models/user.php';
include '../../utils.php';

refreshActivity($conn, $_SESSION['user_id']);

$userRole = $_SESSION['role'];
$actionMessage = $_SESSION['candidate_action_message'] ?? "";
$actionType = $_SESSION['candidate_action_type'] ?? "success";
unset($_SESSION['candidate_action_message'], $_SESSION['candidate_action_type']);
$dbConnected = false;
$dbError = "";
$hasCandidates = false;
$allCandidates = [];
$allElections  = [];
$allStudents = [];
$partyListSchemaReady = ensureCandidatePartyListSchema($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $partyListSchemaReady) {

    // Both admin and moderator can add candidates
    if (isset($_POST['add_candidate'])) {
        $election_id = (int) $_POST['election_id'];
        $firstname = sanitization($_POST['firstname']);
        $middlename = sanitization($_POST['middlename'] ?? '');
        $lastname = sanitization($_POST['lastname']);
        $fullname = trim("$firstname $middlename $lastname");
        $position = sanitization($_POST['position']);
        $party_list = trim(sanitization($_POST['party_list'] ?? '')) ?: 'Independent';
        $bio = sanitization($_POST['bio']);
        $school_id = sanitization($_POST['school_id']);
        $email = sanitization($_POST['email']);
        $contact_number = sanitization($_POST['contact_number']);
        $studentUserId = null;

        if ($userRole === 'admin' && !empty($_POST['student_user_id'])) {
            $student = getStudentById($conn, $_POST['student_user_id'] ?? 0);
            if (!$student) {
                $actionMessage = "Select a registered student from the user list before adding the candidate.";
                $actionType = "danger";
                $_SESSION['candidate_action_message'] = $actionMessage;
                $_SESSION['candidate_action_type'] = $actionType;
                header("Location: view_candidates.php");
                exit();
            }
            $firstname = $student['firstname'];
            $middlename = $student['middlename'];
            $lastname = $student['lastname'];
            $school_id = $student['school_id'];
            $fullname = trim("$firstname $middlename $lastname");
            $email = $student['email'];
            $studentUserId = (int) $student['id'];
        }

        if ($firstname === '' || $lastname === '') {
            $actionMessage = "Candidate first and last names are required.";
            $actionType = "danger";
        } elseif (strlen($firstname) > 100 || strlen($middlename) > 100 || strlen($lastname) > 100 || strlen($fullname) > 150) {
            $actionMessage = "Candidate first, middle, and last names are too long.";
            $actionType = "danger";
        } elseif (addCandidate($conn, $election_id, $firstname, $middlename, $lastname, $position, $party_list, $bio, $school_id, $email, $contact_number, $studentUserId)) {
            $actionMessage = "Candidate '$fullname' has been successfully added.";
        } else {
            $actionMessage = "Error adding candidate: " . mysqli_error($conn);
            $actionType = "danger";
        }
    }

    // Both admin and moderator can edit candidates
    if (isset($_POST['edit_candidate'])) {
        $id = (int) $_POST['candidate_id'];
        $election_id = (int) $_POST['election_id'];
        $firstname = sanitization($_POST['firstname']);
        $middlename = sanitization($_POST['middlename'] ?? '');
        $lastname = sanitization($_POST['lastname']);
        $fullname = trim("$firstname $middlename $lastname");
        $position = sanitization($_POST['position']);
        $party_list = trim(sanitization($_POST['party_list'] ?? '')) ?: 'Independent';
        $bio = sanitization($_POST['bio']);
        $school_id = sanitization($_POST['school_id']);
        $email = sanitization($_POST['email']);
        $contact_number = sanitization($_POST['contact_number']);
        $studentUserId = null;
        $validStudentSelection = true;
        if ($userRole === 'admin' && !empty($_POST['student_user_id'])) {
            $student = getStudentById($conn, $_POST['student_user_id']);
            if (!$student) {
                $actionMessage = "The selected student account is not valid.";
                $actionType = "danger";
                $validStudentSelection = false;
            } else {
                $studentUserId = (int) $student['id'];
                $firstname = $student['firstname'];
                $middlename = $student['middlename'];
                $lastname = $student['lastname'];
                $school_id = $student['school_id'];
                $fullname = trim("$firstname $middlename $lastname");
                $email = $student['email'];
            }
        }

        if ($validStudentSelection && ($firstname === '' || $lastname === '')) {
            $actionMessage = "Candidate first and last names are required.";
            $actionType = "danger";
        } elseif ($validStudentSelection && (strlen($firstname) > 100 || strlen($middlename) > 100 || strlen($lastname) > 100 || strlen($fullname) > 150)) {
            $actionMessage = "Candidate first, middle, and last names are too long.";
            $actionType = "danger";
        } elseif ($validStudentSelection && updateCandidate($conn, $id, $election_id, $firstname, $middlename, $lastname, $position, $party_list, $bio, $school_id, $email, $contact_number, $studentUserId)) {
            $actionMessage = "Candidate '$fullname' has been successfully updated.";
        } else {
            $actionMessage = "Error updating candidate: " . mysqli_error($conn);
            $actionType = "danger";
        }
    }

    // Only admin can delete candidates — moderator requests are silently ignored
    if (isset($_POST['delete_candidate'])) {
        if ($userRole === 'admin') {
            $id = (int) $_POST['candidate_id'];
            if (deleteCandidate($conn, $id)) {
                $actionMessage = "Candidate has been permanently deleted.";
            } else {
                $actionMessage = "Error deleting candidate: " . mysqli_error($conn);
                $actionType = "danger";
            }
        } else {
            $actionMessage = "Access Denied: Moderators cannot delete candidates.";
            $actionType = "danger";
        }
    }

    $_SESSION['candidate_action_message'] = $actionMessage;
    $_SESSION['candidate_action_type'] = $actionType;
    header("Location: view_candidates.php");
    exit();
}

// Fetch data for page display
if ($conn) {
    if ($partyListSchemaReady) {
        $dbConnected = true;
        $allCandidates = getAllCandidates($conn);
        $allElections = getAllElections($conn);
        if ($userRole === 'admin') {
            $allStudents = getStudents($conn);
        }

        if (!empty($allCandidates)) {
            $hasCandidates = true;
        }
    } else {
        $dbError = mysqli_error($conn);
    }
} else {
    $dbError = mysqli_connect_error();
}