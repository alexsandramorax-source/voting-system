<?php
session_start();

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'moderator'], true)) {
    header("Location: ../../index.php");
    exit;
}

require '../../connection.php';
include '../../models/college.php';
include '../../models/election.php';
require_once '../../models/settings.php';
include '../../models/user.php';
include '../../utils.php';

if ($conn) {
    refreshActivity($conn, $_SESSION['user_id']);
}

$dbConnected = false;
$dbError = '';
$dashboardStats = [
    'voters' => 0,
    'ongoing' => 0,
    'upcoming' => 0,
    'completed' => 0,
    'candidates' => 0
];
$currentElection = null;
$recentElections = [];
$appSettings = getDefaultAppSettings();

if (!$conn) {
    $dbError = mysqli_connect_error();
} elseif (!ensureCollegeSchema($conn) || !ensureVoterRegistrySchema($conn) || !ensureElectionCompletionSchema($conn) || !ensureAppSettingsSchema($conn)) {
    $dbError = mysqli_error($conn);
} else {
    $loadedSettings = getAppSettings($conn);
    $counts = mysqli_query($conn, "SELECT
        (SELECT COUNT(*) FROM voters) AS voter_count,
        (SELECT COUNT(*) FROM candidates) AS candidate_count");
    $electionsResult = mysqli_query($conn, "SELECT id, name, department, open_at, close_at, is_closed, completed_at
        FROM elections ORDER BY open_at DESC");

    if ($loadedSettings === false || !$counts || !$electionsResult) {
        $dbError = mysqli_error($conn);
    } else {
        $appSettings = $loadedSettings;
        $countRow = mysqli_fetch_assoc($counts);
        $dashboardStats['voters'] = (int) $countRow['voter_count'];
        $dashboardStats['candidates'] = (int) $countRow['candidate_count'];

        $elections = [];
        while ($election = mysqli_fetch_assoc($electionsResult)) {
            $election['status'] = computeElectionStatus($election['open_at'], $election['close_at'], $election['is_closed']);
            $elections[] = $election;
            if ($election['status'] === 'ongoing') {
                $dashboardStats['ongoing']++;
                if ($currentElection === null) {
                    $currentElection = $election;
                }
            } elseif ($election['status'] === 'upcoming') {
                $dashboardStats['upcoming']++;
            }
            if (!empty($election['completed_at'])) {
                $dashboardStats['completed']++;
            }
        }
        $recentElections = array_slice($elections, 0, 5);
        $dbConnected = true;
    }
}

$dashboardUserName = trim(implode(' ', array_filter([
    $_SESSION['firstname'] ?? '',
    $_SESSION['middlename'] ?? '',
    $_SESSION['lastname'] ?? ''
], function ($part) {
    return trim((string) $part) !== '';
})));
