<?php
session_start();

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'moderator', 'student'], true)) {
    header('Location: ../../index.php');
    exit();
}

require '../../connection.php';
require_once '../../models/election.php';
require_once '../../models/user.php';
require_once '../../models/vote.php';
require_once '../../models/candidate.php';
require_once '../../utils.php';

refreshActivity($conn, $_SESSION['user_id']);

$dbError = '';
$completedElections = [];
$selectedElection = null;
$positionResults = [];

if (!ensureElectionCompletionSchema($conn) || !ensureCandidatePartyListSchema($conn)) {
    $dbError = mysqli_error($conn);
} else {
    $completedElections = getCompletedElections($conn);
    $selectedId = filter_var($_GET['election_id'] ?? null, FILTER_VALIDATE_INT);
    if ($completedElections === false) {
        $dbError = mysqli_error($conn);
    } else {
        foreach ($completedElections as $election) {
            if ($selectedId !== false && $selectedId !== null && $selectedId > 0
                && (int) $election['id'] === $selectedId) {
                $selectedElection = $election;
                break;
            }
        }
        if ($selectedElection === null && $completedElections !== []) {
            $selectedElection = $completedElections[0];
        }

        if ($selectedElection) {
            $tally = getCompletedElectionTally($conn, (int) $selectedElection['id']);
            if ($tally === false) {
                $dbError = mysqli_error($conn) ?: 'Unable to load candidate vote totals.';
            } else {
                foreach ($tally as $position => $candidates) {
                    $highestVotes = $candidates === [] ? 0 : max(array_column($candidates, 'votes'));
                    $positionResults[] = [
                        'position' => $position,
                        'candidates' => array_map(function ($candidate) use ($highestVotes) {
                            $candidate['standing'] = $highestVotes === 0
                                ? 'No votes'
                                : ($candidate['votes'] === $highestVotes ? 'Winner' : 'Loser');
                            return $candidate;
                        }, $candidates)
                    ];
                }
            }
        }
    }
}
