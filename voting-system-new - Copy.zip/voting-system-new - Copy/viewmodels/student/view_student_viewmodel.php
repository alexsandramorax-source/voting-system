<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../../index.php");
    exit();
}

require '../../connection.php';
include '../../models/election.php';
include '../../models/user.php';
include '../../models/candidate.php';
include '../../models/vote.php';

refreshActivity($conn, $_SESSION['user_id']);

$dbConnected = false;
$dbError = "";
$hasElections = false;
$ongoingElections = [];
$candidatesByElection = [];
$submittedElections = [];
$message = "";
$messageType = "danger";

$studentId = (int) $_SESSION['user_id'];
$studentFirstname = $_SESSION['firstname'];
$studentMiddlename = $_SESSION['middlename'] ?? '';
$studentLastname = $_SESSION['lastname'];
$studentDepartment = $_SESSION['department'];

if ($conn && ensureCandidatePartyListSchema($conn)) {
    $dbConnected = true;
    $ongoingElections = getOngoingElectionsForStudent($conn, $studentDepartment);

    foreach ($ongoingElections as $election) {
        $electionId = (int) $election['id'];
        $candidatesByElection[$electionId] = getCandidatesGroupedByPosition($conn, $electionId);
        if (hasSubmittedBallot($conn, $electionId, $studentId)) {
            $submittedElections[$electionId] = true;
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_ballot'])) {
        $electionId = (int) ($_POST['election_id'] ?? 0);
        $eligibleElection = null;
        foreach ($ongoingElections as $election) {
            if ((int) $election['id'] === $electionId) {
                $eligibleElection = $election;
                break;
            }
        }

        if (!$eligibleElection) {
            $message = "This election is no longer available to you.";
        } elseif (isset($submittedElections[$electionId])) {
            $message = "You have already submitted a ballot for this election.";
        } else {
            $positionCandidates = $candidatesByElection[$electionId] ?? [];
            $submittedVotes = isset($_POST['vote']) && is_array($_POST['vote']) ? $_POST['vote'] : [];
            $validatedVotes = [];

            foreach ($positionCandidates as $position => $candidates) {
                if (!isset($submittedVotes[$position]) || !is_scalar($submittedVotes[$position])) {
                    $message = "Please choose one candidate or abstain for every position.";
                    break;
                }

                $selectedCandidate = (string) $submittedVotes[$position];
                if ($selectedCandidate === 'abstain') {
                    $validatedVotes[$position] = null;
                    continue;
                }

                $candidateIsEligible = false;
                foreach ($candidates as $candidate) {
                    if ((string) $candidate['id'] === $selectedCandidate) {
                        $validatedVotes[$position] = $selectedCandidate;
                        $candidateIsEligible = true;
                        break;
                    }
                }

                if (!$candidateIsEligible) {
                    $message = "A selected candidate does not belong to this position and election.";
                    break;
                }
            }

            if ($message === "" && count($validatedVotes) !== count($positionCandidates)) {
                $message = "The ballot could not be validated. Please review your choices and try again.";
            }

            if ($message === "") {
                if (!mysqli_begin_transaction($conn)) {
                    $message = "Unable to begin ballot submission: " . mysqli_error($conn);
                } else {
                    $saved = true;
                    foreach ($validatedVotes as $position => $candidateId) {
                        if (!castVote($conn, $electionId, $studentId, $position, $candidateId)) {
                            $message = "Unable to save your vote for $position: " . mysqli_error($conn);
                            $saved = false;
                            break;
                        }
                    }

                    if ($saved && !markBallotSubmitted($conn, $electionId, $studentId)) {
                        $message = "Unable to mark your ballot as submitted: " . mysqli_error($conn);
                        $saved = false;
                    }

                    if ($saved && mysqli_commit($conn)) {
                        $_SESSION['receipt_fresh'] = true;
                        header("Location: receipt.php?election_id=$electionId");
                        exit();
                    }

                    if (!$saved) {
                        mysqli_rollback($conn);
                    } else {
                        $message = "Unable to complete ballot submission: " . mysqli_error($conn);
                        mysqli_rollback($conn);
                    }
                }
            }
        }
    }

    $hasElections = !empty($ongoingElections);
} else {
    $dbError = $conn ? mysqli_error($conn) : mysqli_connect_error();
}
