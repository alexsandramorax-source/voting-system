<?php
session_start();

if (!isset($_SESSION['role'], $_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../../index.php');
    exit;
}

require '../../connection.php';
require_once '../../models/settings.php';
require_once '../../models/user.php';
require_once '../../models/college.php';
require_once '../../models/profile_correction_request.php';
require_once '../../utils.php';

$message = $_SESSION['student_settings_message'] ?? '';
$messageType = $_SESSION['student_settings_message_type'] ?? 'success';
unset($_SESSION['student_settings_message'], $_SESSION['student_settings_message_type']);
$dbError = '';
$student = false;
$colleges = [];
$studentRequests = [];
$minimumPasswordLength = 8;
$settingsSection = $_GET['section'] ?? 'home';
if (!is_string($settingsSection) || !in_array($settingsSection, ['home', 'password', 'profile'], true)) {
    $settingsSection = 'home';
}
$csrfToken = $_SESSION['student_settings_csrf'] ??= bin2hex(random_bytes(32));

if (!$conn) {
    $dbError = mysqli_connect_error();
} elseif (!ensureAppSettingsSchema($conn)
    || !ensureCollegeSchema($conn)
    || !ensureProfileCorrectionRequestSchema($conn)) {
    $dbError = mysqli_error($conn);
} else {
    refreshActivity($conn, (int) $_SESSION['user_id']);
    $student = getUserById($conn, (int) $_SESSION['user_id']);
    if (!$student || $student['role'] !== 'student') {
        header('Location: ../../index.php');
        exit;
    }
    $settings = getAppSettings($conn);
    if ($settings === false) {
        $dbError = mysqli_error($conn);
    } else {
        $minimumPasswordLength = filter_var($settings['minimum_password_length'], FILTER_VALIDATE_INT);
        if ($minimumPasswordLength === false || $minimumPasswordLength < 8 || $minimumPasswordLength > 64) {
            $dbError = 'The configured minimum password length is invalid. Contact an administrator.';
            $minimumPasswordLength = 8;
        }
    }
    $colleges = getColleges($conn);
    $studentRequests = getStudentProfileCorrectionRequests($conn, (int) $student['id']);
    if ($studentRequests === false) {
        $dbError = mysqli_error($conn);
        $studentRequests = [];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $dbError === '') {
    $submittedToken = $_POST['csrf_token'] ?? '';
    if (!is_string($submittedToken) || !hash_equals($csrfToken, $submittedToken)) {
        $message = 'Your form session expired. Please try again.';
        $messageType = 'danger';
    } elseif (isset($_POST['change_password'])) {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!is_string($currentPassword) || !is_string($newPassword) || !is_string($confirmPassword)) {
            $message = 'Enter valid password values.';
            $messageType = 'danger';
        } elseif (strlen($newPassword) < $minimumPasswordLength) {
            $message = "New password must be at least {$minimumPasswordLength} characters long.";
            $messageType = 'danger';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'The new passwords do not match.';
            $messageType = 'danger';
        } elseif ($newPassword === $currentPassword) {
            $message = 'Choose a new password different from your current password.';
            $messageType = 'danger';
        } elseif (!getUser($conn, $student['email'], $currentPassword)) {
            $message = 'The current password is incorrect.';
            $messageType = 'danger';
        } elseif (!updateUserPassword($conn, (int) $student['id'], $newPassword)) {
            $message = 'Unable to update your password. Please try again.';
            $messageType = 'danger';
        } else {
            $message = 'Your password has been changed.';
        }
    } elseif (isset($_POST['submit_profile_correction'])) {
        $profileFields = [
            'school_id' => 'school_id',
            'firstname' => 'firstname',
            'middlename' => 'middlename',
            'lastname' => 'lastname',
            'email' => 'email',
            'department' => 'department',
            'year_level' => 'year_level'
        ];
        $profile = [];
        $invalidProfileInput = false;
        foreach ($profileFields as $key => $field) {
            $value = $_POST[$field] ?? '';
            if (!is_string($value)) {
                $invalidProfileInput = true;
                break;
            }
            $profile[$key] = trim($value);
        }
        $correctionMessageInput = $_POST['correction_message'] ?? '';
        if (!is_string($correctionMessageInput)) {
            $invalidProfileInput = true;
            $correctionMessageInput = '';
        }
        $correctionMessage = trim($correctionMessageInput);
        if ($invalidProfileInput) {
            $profile = array_fill_keys(array_keys($profileFields), '');
        }
        $sameAsCurrent = $profile['school_id'] === $student['school_id']
            && $profile['firstname'] === $student['firstname']
            && $profile['middlename'] === ($student['middlename'] ?? '')
            && $profile['lastname'] === $student['lastname']
            && $profile['email'] === $student['email']
            && $profile['department'] === $student['department']
            && $profile['year_level'] === ($student['year_level'] ?? '');

        if ($invalidProfileInput || $profile['school_id'] === '' || strlen($profile['school_id']) > 50
            || $profile['firstname'] === '' || strlen($profile['firstname']) > 100
            || strlen($profile['middlename']) > 100
            || $profile['lastname'] === '' || strlen($profile['lastname']) > 100
            || !filter_var($profile['email'], FILTER_VALIDATE_EMAIL) || strlen($profile['email']) > 100
            || strlen($profile['year_level']) > 30
            || strlen($correctionMessage) > 1000) {
            $message = 'Check the profile details. Names, Student ID, email, year level, or message exceed the allowed format or length.';
            $messageType = 'danger';
        } elseif (!isRegisteredCollege($conn, $profile['department'])) {
            $message = 'Select a registered college or department.';
            $messageType = 'danger';
        } elseif ($sameAsCurrent) {
            $message = 'Make at least one change to your profile details before submitting a request.';
            $messageType = 'danger';
        } elseif (!createProfileCorrectionRequest($conn, (int) $student['id'], $profile, $correctionMessage)) {
            $message = 'Unable to submit your correction request: ' . mysqli_error($conn);
            $messageType = 'danger';
        } else {
            $message = 'Your profile correction request was sent to an administrator for review.';
        }
    } else {
        $message = 'The submitted form could not be identified.';
        $messageType = 'danger';
    }

    $_SESSION['student_settings_message'] = $message;
    $_SESSION['student_settings_message_type'] = $messageType;
    $redirectSection = isset($_POST['change_password']) ? 'password' : 'profile';
    header('Location: settings.php?section=' . $redirectSection);
    exit;
}
