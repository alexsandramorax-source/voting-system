<?php
require '../../viewmodels/admin/profile_correction_requests_viewmodel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Correction Requests | Voting System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0">
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body class="bg-dashboard vh-100 overflow-hidden d-flex flex-column flex-md-row">
    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0"
         tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width:250px">
        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3">
            <a href="../shared/dashboard.php" class="d-none d-md-flex align-items-center me-md-auto text-white text-decoration-none px-2"><span class="fs-4 fw-bold">Voting System</span></a>
            <hr class="d-none d-md-block">
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="../shared/dashboard.php" class="nav-link"><span class="material-symbols-outlined">home</span> Home</a></li>
                <li><a href="view_users.php" class="nav-link"><span class="material-symbols-outlined">groups</span> View Users</a></li>
                <li><a href="profile_correction_requests.php" class="nav-link active" aria-current="page"><span class="material-symbols-outlined">manage_accounts</span> Profile Requests</a></li>
                <li><a href="view_departments.php" class="nav-link"><span class="material-symbols-outlined">domain</span> Departments</a></li>
                <li><a href="view_elections.php" class="nav-link"><span class="material-symbols-outlined">how_to_vote</span> Elections</a></li>
                <li><a href="../shared/view_candidates.php" class="nav-link"><span class="material-symbols-outlined">person</span> Candidates</a></li>
                <li><a href="../shared/reports.php" class="nav-link"><span class="material-symbols-outlined">analytics</span> Reports</a></li>
                <li><a href="../shared/results.php" class="nav-link"><span class="material-symbols-outlined">emoji_events</span> Results</a></li>
                <li><a href="settings.php" class="nav-link"><span class="material-symbols-outlined">settings</span> Settings</a></li>
            </ul>
        </div>
    </div>
    <div class="w-100 d-flex flex-column overflow-auto">
        <nav class="navbar navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">
                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>
                <span class="navbar-brand mb-0 h1 fw-bold fs-5">Profile Correction Requests</span>
            </div>
        </nav>
        <main class="container-fluid p-3 p-md-4">
            <?php if ($dbError !== ''): ?>
                <div class="alert alert-danger">Unable to load profile requests: <?php echo htmlspecialchars($dbError); ?></div>
            <?php else: ?>
                <?php if ($message !== ''): ?>
                    <div class="alert alert-<?php echo htmlspecialchars($messageType); ?> alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($message); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if ($requests === []): ?>
                    <section class="bg-white rounded-3 shadow-sm border p-4 text-center">
                        <h1 class="h5 fw-bold">No profile correction requests</h1>
                        <p class="text-muted mb-0">Student requests will appear here for review.</p>
                    </section>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($requests as $request): ?>
                            <div class="col-12">
                                <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4">
                                    <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
                                        <div>
                                            <h1 class="h5 fw-bold mb-1">
                                                <?php echo htmlspecialchars(trim(($request['current_firstname'] ?? '') . ' ' . ($request['current_middlename'] ?? '') . ' ' . ($request['current_lastname'] ?? ''))); ?>
                                            </h1>
                                            <div class="text-muted small">
                                                Student ID: <?php echo htmlspecialchars($request['current_student_id'] ?? 'Account unavailable'); ?>
                                                · <?php echo htmlspecialchars($request['current_email'] ?? ''); ?>
                                                · Submitted <?php echo htmlspecialchars($request['created_at']); ?>
                                            </div>
                                        </div>
                                        <span class="badge bg-<?php echo $request['status'] === 'pending' ? 'warning text-dark' : ($request['status'] === 'approved' ? 'success' : 'secondary'); ?>">
                                            <?php echo htmlspecialchars(ucfirst($request['status'])); ?>
                                        </span>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered align-middle mb-3">
                                            <thead class="table-light"><tr><th>Field</th><th>Current</th><th>Requested</th></tr></thead>
                                            <tbody>
                                                <?php foreach ([
                                                    'Student ID' => ['current_student_id', 'requested_student_id'],
                                                    'First name' => ['current_firstname', 'requested_firstname'],
                                                    'Middle name' => ['current_middlename', 'requested_middlename'],
                                                    'Last name' => ['current_lastname', 'requested_lastname'],
                                                    'Email' => ['current_email', 'requested_email'],
                                                    'College / department' => ['current_department', 'requested_department'],
                                                    'Year level' => ['current_year_level', 'requested_year_level']
                                                ] as $label => [$currentField, $requestedField]): ?>
                                                    <tr>
                                                        <th><?php echo htmlspecialchars($label); ?></th>
                                                        <td><?php echo htmlspecialchars($request[$currentField] ?? ''); ?></td>
                                                        <td><?php echo htmlspecialchars($request[$requestedField] ?? ''); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php if ($request['message'] !== ''): ?>
                                        <p><strong>Student note:</strong> <?php echo nl2br(htmlspecialchars($request['message'])); ?></p>
                                    <?php endif; ?>
                                    <?php if ($request['status'] === 'pending'): ?>
                                        <form method="post" action="profile_correction_requests.php" class="d-flex gap-2">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                            <input type="hidden" name="request_id" value="<?php echo (int) $request['id']; ?>">
                                            <button type="submit" name="decision" value="approved" class="btn btn-success">Approve and update records</button>
                                            <button type="submit" name="decision" value="rejected" class="btn btn-outline-danger">Reject</button>
                                        </form>
                                    <?php elseif ($request['reviewed_at'] !== null): ?>
                                        <p class="text-muted small mb-0">Reviewed <?php echo htmlspecialchars($request['reviewed_at']); ?></p>
                                    <?php endif; ?>
                                </section>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
