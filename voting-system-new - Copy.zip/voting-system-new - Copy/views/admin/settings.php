<?php require '../../viewmodels/admin/settings_viewmodel.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Settings | <?php echo htmlspecialchars($appSettings['system_name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0">
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body class="bg-dashboard vh-100 overflow-hidden d-flex flex-column flex-md-row">
    <aside class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0" tabindex="-1" id="sidebarMenu" style="width:250px">
        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3">
            <a href="../shared/dashboard.php" class="d-none d-md-flex align-items-center me-md-auto text-white text-decoration-none px-2">
                <span class="fs-4 fw-bold"><?php echo htmlspecialchars($appSettings['system_name']); ?></span>
            </a>
            <hr class="d-none d-md-block">
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="../shared/dashboard.php" class="nav-link"><span class="material-symbols-outlined">home</span> Home</a></li>
                <li><a href="view_users.php" class="nav-link"><span class="material-symbols-outlined">groups</span> View Users</a></li>
                <li><a href="profile_correction_requests.php" class="nav-link"><span class="material-symbols-outlined">manage_accounts</span> Profile Requests</a></li>
                <li><a href="view_departments.php" class="nav-link"><span class="material-symbols-outlined">domain</span> Departments</a></li>
                <li><a href="view_elections.php" class="nav-link"><span class="material-symbols-outlined">how_to_vote</span> Elections</a></li>
                <li><a href="../shared/view_candidates.php" class="nav-link"><span class="material-symbols-outlined">person</span> Candidates</a></li>
                <li><a href="../shared/reports.php" class="nav-link"><span class="material-symbols-outlined">analytics</span> Reports</a></li>
                <li><a href="../shared/results.php" class="nav-link"><span class="material-symbols-outlined">emoji_events</span> Results</a></li>
                <li><a href="settings.php" class="nav-link active" aria-current="page"><span class="material-symbols-outlined">settings</span> Settings</a></li>
            </ul>
        </div>
    </aside>

    <div class="w-100 d-flex flex-column overflow-auto">
        <nav class="navbar navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">
                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>
                <span class="navbar-brand mb-0 h1 fw-bold fs-5">System Settings</span>
                <span class="ms-auto fw-semibold"><?php echo htmlspecialchars(trim(($_SESSION['firstname'] ?? '') . ' ' . ($_SESSION['lastname'] ?? ''))); ?></span>
            </div>
        </nav>

        <main class="container-fluid p-3 p-md-4">
            <?php if ($settingsMessage !== ''): ?>
                <div class="alert alert-<?php echo htmlspecialchars($settingsMessageType); ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($settingsMessage); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if ($dbError !== ''): ?>
                <div class="alert alert-danger" role="alert">Unable to load settings: <?php echo htmlspecialchars($dbError); ?></div>
            <?php else: ?>
                <form method="POST" class="bg-white rounded-3 shadow-sm border p-3 p-md-4">
                    <section class="mb-4" aria-labelledby="systemInfoHeading">
                        <h1 class="h5 fw-bold" id="systemInfoHeading">System Information</h1>
                        <p class="text-muted small">Set the system branding and contact details.</p>
                        <div class="row g-3">
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="systemName">System name</label>
                                <input class="form-control" id="systemName" name="system_name" maxlength="100" required value="<?php echo htmlspecialchars($appSettings['system_name']); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="institutionName">Institution / organization</label>
                                <input class="form-control" id="institutionName" name="institution_name" maxlength="100" required value="<?php echo htmlspecialchars($appSettings['institution_name']); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="supportEmail">Support email</label>
                                <input type="email" class="form-control" id="supportEmail" name="support_email" maxlength="100" value="<?php echo htmlspecialchars($appSettings['support_email']); ?>">
                            </div>
                        </div>
                    </section>

                    <hr>
                    <section class="mb-4" aria-labelledby="electionDefaultsHeading">
                        <h2 class="h5 fw-bold" id="electionDefaultsHeading">Election Defaults</h2>
                        <p class="text-muted small">When setting an election opening time, the closing time will default to this duration. Admins can still adjust it for each election.</p>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label class="form-label" for="defaultElectionDuration">Default election duration (hours)</label>
                            <input type="number" class="form-control" id="defaultElectionDuration" name="default_election_duration_hours" min="1" max="720" required value="<?php echo htmlspecialchars($appSettings['default_election_duration_hours']); ?>">
                        </div>
                    </section>

                    <hr>
                    <section class="mb-4" aria-labelledby="securityDefaultsHeading">
                        <h2 class="h5 fw-bold" id="securityDefaultsHeading">Voter Accounts &amp; Security</h2>
                        <div class="row g-3">
                            <div class="col-12 col-md-6 col-lg-4">
                                <label class="form-label" for="sessionTimeout">Session timeout (minutes)</label>
                                <input type="number" class="form-control" id="sessionTimeout" name="session_timeout_minutes" min="5" max="1440" required value="<?php echo htmlspecialchars($appSettings['session_timeout_minutes']); ?>">
                                <div class="form-text">Inactive accounts can sign in again after this interval.</div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-4">
                                <label class="form-label" for="minimumPasswordLength">Minimum changed-password length</label>
                                <input type="number" class="form-control" id="minimumPasswordLength" name="minimum_password_length" min="8" max="64" required value="<?php echo htmlspecialchars($appSettings['minimum_password_length']); ?>">
                            </div>
                            <div class="col-12">
                                <input type="hidden" name="require_password_change" value="0">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="requirePasswordChange" name="require_password_change" value="1" <?php echo $appSettings['require_password_change'] === '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="requirePasswordChange">Require voters to change default passwords at first login</label>
                                </div>
                            </div>
                        </div>
                    </section>

                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn text-white" style="background-color:#48672F">Save Settings</button>
                    </div>
                </form>
            <?php endif; ?>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
