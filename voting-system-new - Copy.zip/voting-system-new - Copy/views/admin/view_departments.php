<?php
require '../../viewmodels/admin/view_departments_viewmodel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SBO Voting System - Departments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0">
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body class="bg-dashboard vh-100 overflow-hidden d-flex flex-column flex-md-row">
    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0"
         tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width: 250px;">
        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3">
            <a href="../shared/dashboard.php" class="d-none d-md-flex align-items-center me-md-auto text-white text-decoration-none px-2">
                <span class="fs-4 fw-bold">Voting System</span>
            </a>
            <hr class="d-none d-md-block">
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="../shared/dashboard.php" class="nav-link"><span class="material-symbols-outlined">home</span> Home</a></li>
                <li><a href="view_users.php" class="nav-link"><span class="material-symbols-outlined">groups</span> View Users</a></li>
                <li><a href="profile_correction_requests.php" class="nav-link"><span class="material-symbols-outlined">manage_accounts</span> Profile Requests</a></li>
                <li><a href="view_departments.php" class="nav-link active" aria-current="page"><span class="material-symbols-outlined">domain</span> Departments</a></li>
                <li><a href="view_elections.php" class="nav-link"><span class="material-symbols-outlined">how_to_vote</span> Elections</a></li>
                <li><a href="../shared/view_candidates.php" class="nav-link"><span class="material-symbols-outlined">person</span> Candidates</a></li>
                <li><a href="../shared/reports.php" class="nav-link"><span class="material-symbols-outlined">analytics</span> Reports</a></li>
                <li><a href="../shared/results.php" class="nav-link"><span class="material-symbols-outlined">emoji_events</span> Results</a></li>
            </ul>
        </div>
    </div>

    <div class="w-100 d-flex flex-column overflow-auto">
        <nav class="navbar navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">
                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>
                <span class="navbar-brand mb-0 h1 fw-bold fs-5">Departments</span>
                <div class="d-flex align-items-center ms-auto gap-2">
                    <span class="d-none d-sm-inline"><?php echo htmlspecialchars(trim(($_SESSION['firstname'] ?? '') . ' ' . ($_SESSION['middlename'] ?? '') . ' ' . ($_SESSION['lastname'] ?? ''))); ?></span>
                    <a class="btn btn-sm btn-outline-danger" href="../../viewmodels/logout_viewmodel.php">Sign out</a>
                </div>
            </div>
        </nav>

        <main class="container-fluid p-3 p-md-4">
            <?php if ($actionMessage !== ''): ?>
                <div class="alert alert-<?php echo htmlspecialchars($actionType); ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($actionMessage); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($dbError !== ''): ?>
                <div class="alert alert-danger">Unable to load departments: <?php echo htmlspecialchars($dbError); ?></div>
            <?php else: ?>
                <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                        <div>
                            <h1 class="h4 fw-bold mb-1">Department Management</h1>
                            <p class="text-muted mb-0">Departments registered in the database, including their user and election assignments.</p>
                        </div>
                        <button class="btn text-white" style="background-color:#48672F" data-bs-toggle="modal" data-bs-target="#addDepartmentModal">
                            <span class="material-symbols-outlined align-middle">add</span> Add Department
                        </button>
                    </div>

                    <?php if ($allDepartments === []): ?>
                        <div class="alert alert-secondary mb-0">No departments are registered yet.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Department / College</th>
                                        <th>Code</th>
                                        <th>Users</th>
                                        <th>Elections</th>
                                        <th class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($allDepartments as $index => $department): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td class="fw-semibold"><?php echo htmlspecialchars($department['name']); ?></td>
                                            <td><?php echo htmlspecialchars($department['code'] ?? ''); ?></td>
                                            <td><?php echo (int) $department['user_count']; ?></td>
                                            <td><?php echo (int) $department['election_count']; ?></td>
                                            <td class="text-end text-nowrap">
                                                <button type="button" class="btn btn-sm btn-outline-primary"
                                                    data-bs-toggle="modal" data-bs-target="#editDepartmentModal"
                                                    data-id="<?php echo (int) $department['id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($department['name']); ?>"
                                                    data-code="<?php echo htmlspecialchars($department['code'] ?? ''); ?>">
                                                    Edit
                                                </button>
                                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this department? Departments assigned to users or elections cannot be deleted.');">
                                                    <input type="hidden" name="department_id" value="<?php echo (int) $department['id']; ?>">
                                                    <button type="submit" name="delete_department" class="btn btn-sm btn-outline-danger">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <p class="form-text mb-0">Departments assigned to users or elections cannot be deleted. Rename a department to update its assignments.</p>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        </main>
    </div>

    <div class="modal fade" id="addDepartmentModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header text-white" style="background-color:#48672F">
                        <h2 class="modal-title fs-5">Add Department</h2>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <label for="add_department_name" class="form-label">Department / College name</label>
                        <input id="add_department_name" class="form-control mb-3" name="department_name" maxlength="100" required>
                        <label for="add_department_code" class="form-label">Code (optional)</label>
                        <input id="add_department_code" class="form-control" name="department_code" maxlength="30">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_department" class="btn text-white" style="background-color:#48672F">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editDepartmentModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-primary text-white">
                        <h2 class="modal-title fs-5">Edit Department</h2>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="department_id" id="edit_department_id">
                        <label for="edit_department_name" class="form-label">Department / College name</label>
                        <input id="edit_department_name" class="form-control mb-3" name="department_name" maxlength="100" required>
                        <label for="edit_department_code" class="form-label">Code (optional)</label>
                        <input id="edit_department_code" class="form-control" name="department_code" maxlength="30">
                        <p class="form-text mb-0 mt-2">Changing the name also updates users and elections assigned to this department.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="edit_department" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('editDepartmentModal').addEventListener('show.bs.modal', (event) => {
            const button = event.relatedTarget;
            document.getElementById('edit_department_id').value = button.dataset.id;
            document.getElementById('edit_department_name').value = button.dataset.name;
            document.getElementById('edit_department_code').value = button.dataset.code;
        });
    </script>
</body>
</html>
