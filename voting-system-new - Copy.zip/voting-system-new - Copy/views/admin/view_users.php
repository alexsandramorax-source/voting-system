<?php
require '../../viewmodels/admin/view_users_viewmodel.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SBO Voting System - Manage Users</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="../../assets/style.css">
    <!-- <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar-bg {
            background-color: #48672F !important;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-link:hover,
        .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
        }

        .btn-outline-theme {
            color: #48672F;
            border-color: #48672F;
        }

        .btn-outline-theme:hover,
        .btn-outline-theme.active {
            background-color: #48672F;
            color: white;
        }
    </style> -->
</head>

<body class="vh-100 overflow-hidden d-flex flex-column flex-md-row">

    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0" tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width: 250px;">

        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3 p-md-3">
            <a href="#" class="d-none d-md-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none px-2">
                <span class="fs-4 fw-bold">Voting System</span>
            </a>
            <hr class="d-none d-md-block">

            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="../shared/dashboard.php" class="nav-link">
                        <span class="material-symbols-outlined">Home</span>
                        Home
                    </a>
                </li>
                <li>
                    <a href="#" class="nav-link active" aria-current="page">
                        <span class="material-symbols-outlined">groups</span>
                        View Users
                    </a>
                </li>
                <li>
                    <a href="profile_correction_requests.php" class="nav-link">
                        <span class="material-symbols-outlined">manage_accounts</span>
                        Profile Requests
                    </a>
                </li>
                <li>
                    <a href="view_departments.php" class="nav-link">
                        <span class="material-symbols-outlined">domain</span>
                        Departments
                    </a>
                </li>
                <li>
                    <a href="../admin/view_elections.php" class="nav-link">
                        <span class="material-symbols-outlined">how_to_vote</span>
                        Elections
                    </a>
                </li>
                <li>
                    <a href="../shared/view_candidates.php" class="nav-link">
                        <span class="material-symbols-outlined">person</span>
                        Candidates
                    </a>
                </li>
                <li>
                    <a href="../shared/reports.php" class="nav-link">
                        <span class="material-symbols-outlined">analytics</span>
                        Reports
                    </a>
                </li>
                <li>
                    <a href="../shared/results.php" class="nav-link">
                        <span class="material-symbols-outlined">emoji_events</span>
                        Results
                    </a>
                </li>
                <li>
                    <a href="settings.php" class="nav-link">
                        <span class="material-symbols-outlined">settings</span>
                        Settings
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="w-100 d-flex flex-column overflow-auto">

        <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">

                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>

                <span class="navbar-brand mb-0 h1 fw-bold fs-5 fs-md-4 text-truncate">User Management</span>

                <div class="d-flex align-items-center ms-auto">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="topbarUserDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="material-symbols-outlined me-1 me-md-2 text-muted">account_circle</span>
                            <strong class="d-none d-sm-inline">Admin User</strong>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="topbarUserDropdown">
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2 text-danger fw-bold" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                    <span class="material-symbols-outlined" style="font-size: 1.2rem;">logout</span> Sign out
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container-fluid p-3 p-md-4">

            <?php if (!empty($actionMessage)): ?>
                <div class="alert alert-<?php echo htmlspecialchars($actionType); ?> alert-dismissible fade show mb-4" role="alert">
                    <?php echo htmlspecialchars($actionMessage); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($importResults && !empty($importResults['credentials'])): ?>
                <div class="bg-white rounded-3 shadow-sm border p-3 p-md-4 mb-4">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                        <div>
                            <h2 class="h5 mb-1">Voter login credentials</h2>
                            <p class="text-muted small mb-0">Each listed voter uses the default password shown; passwords are stored as hashes in the database.</p>
                        </div>
                        <button type="button" id="downloadCredentials" class="btn btn-outline-success">Download credentials CSV</button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered align-middle mb-0" id="credentialsTable">
                            <thead class="table-light">
                                <tr><th>Student ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th><th>Email</th><th>College / Department</th><th>Year Level</th><th>Default Password</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($importResults['credentials'] as $credential): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($credential['Student_id']); ?></td>
                                        <td><?php echo htmlspecialchars($credential['firstname']); ?></td>
                                        <td><?php echo htmlspecialchars($credential['middlename']); ?></td>
                                        <td><?php echo htmlspecialchars($credential['lastname']); ?></td>
                                        <td><?php echo htmlspecialchars($credential['email']); ?></td>
                                        <td><?php echo htmlspecialchars($credential['department']); ?></td>
                                        <td><?php echo htmlspecialchars($credential['year_level']); ?></td>
                                        <td><code><?php echo htmlspecialchars($credential['password']); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($importResults && !empty($importResults['errors'])): ?>
                <div class="alert alert-warning">
                    <strong>Some spreadsheet rows were skipped:</strong>
                    <ul class="mb-0 mt-2">
                        <?php foreach ($importResults['errors'] as $importError): ?>
                            <li><?php echo htmlspecialchars($importError); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if (!$dbConnected): ?>

                <div class="d-flex flex-column justify-content-center align-items-center bg-white border rounded shadow-sm p-4 p-md-5 mt-4 text-center" style="min-height: 60vh;">
                    <span class="material-symbols-outlined text-danger mb-3" style="font-size: 5rem;">database_off</span>
                    <h2 class="display-6 fw-bold text-dark mb-2 fs-3 fs-md-2">Unable to connect to database</h2>
                    <p class="text-danger small mb-5 bg-light p-3 border rounded w-100" style="max-width: 600px; word-wrap: break-word;">
                        <strong>System Error:</strong> <?php echo htmlspecialchars($dbError); ?>
                    </p>
                    <button onclick="window.location.reload();" class="btn btn-lg text-white d-flex align-items-center gap-2 px-4 px-md-5 py-2 py-md-3 shadow" style="background-color: #6c757d; border-radius: 50px;">
                        <span class="material-symbols-outlined fs-3">refresh</span>
                        <span class="fs-5 fs-md-4">Reload Page</span>
                    </button>
                </div>

            <?php elseif (!$hasUsers): ?>

                <div class="d-flex flex-column justify-content-center align-items-center bg-white border rounded shadow-sm p-4 p-md-5 mt-4 text-center" style="min-height: 60vh;">
                    <span class="material-symbols-outlined text-muted mb-3" style="font-size: 5rem;">group_off</span>
                    <h2 class="display-6 fw-bold text-dark mb-2 fs-3 fs-md-2">No users found</h2>
                    <p class="text-muted mb-5 fs-6 fs-md-5">The database is connected, but there are currently no users registered in the system.</p>

                    <button class="btn btn-lg text-white d-flex align-items-center gap-2 px-4 px-md-5 py-2 py-md-3 shadow" data-bs-toggle="modal" data-bs-target="#addUserModal" style="background-color: #48672F; border-radius: 50px;">
                        <span class="material-symbols-outlined fs-3">person_add</span>
                        <span class="fs-5 fs-md-4">Add First User</span>
                    </button>
                    <div class="d-flex gap-2 mt-3 flex-wrap justify-content-center">
                        <button class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#addCollegeModal">Register College / Department</button>
                        <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#importVotersModal">Import Voter List</button>
                    </div>
                </div>

            <?php else: ?>

                <div class="bg-white rounded-3 shadow-sm border p-3 p-md-4">

                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">

                        <div class="d-flex gap-2 flex-wrap">
                            <select id="roleFilter" class="form-select form-select-sm" aria-label="Filter by role">
                                <option value="all">All roles</option>
                                <option value="admin">Admins</option>
                                <option value="moderator">Moderators</option>
                                <option value="student">Students / Voters</option>
                            </select>
                            <select id="collegeFilter" class="form-select form-select-sm" aria-label="Filter by college">
                                <option value="all">All colleges / departments</option>
                                <?php foreach ($allColleges as $college): ?>
                                    <option value="<?php echo htmlspecialchars($college['name']); ?>"><?php echo htmlspecialchars($college['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="d-flex gap-2 flex-wrap">
                            <button class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#addCollegeModal">Register College / Department</button>
                            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#importVotersModal">Import Voter List</button>
                            <form method="POST" onsubmit="return confirm('Reset every student voter password to 123456? This signs them out and requires a password change at next login.');">
                                <button type="submit" name="generate_voter_passwords" class="btn btn-outline-danger">Generate Default Passwords</button>
                            </form>
                            <button class="btn text-white d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addUserModal" style="background-color: #48672F;">
                                <span class="material-symbols-outlined">person_add</span> Add User
                            </button>
                        </div>
                    </div>

                    <div class="alert alert-warning py-2 small" role="alert">
                        This action resets every student voter password to <code>123456</code>, ends active sessions, and requires a password change at next login. Passwords are stored as hashes.
                    </div>

                    <div class="alert alert-info py-2 small d-flex align-items-center gap-2 border-0" style="background-color: rgba(13, 202, 240, 0.1); color: #087990;" role="alert">
                        <span class="material-symbols-outlined fs-5">info</span>
                        For system integrity, your currently active account is excluded from this list.
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle border text-nowrap">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Student ID</th>
                                    <th scope="col">First Name</th>
                                    <th scope="col">Middle Name</th>
                                    <th scope="col">Last Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">College / Department</th>
                                    <th scope="col">Year Level</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Account Status</th>
                                    <th scope="col" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($allUsers as $index => $user): ?>
                                    <tr data-role="<?php echo htmlspecialchars($user['role']); ?>" data-college="<?php echo htmlspecialchars($user['department']); ?>">
                                        <td><?php echo $index + 1; ?></td>

                                        <td><?php echo htmlspecialchars($user['school_id']); ?></td>
                                        <td><?php echo htmlspecialchars($user['firstname'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($user['middlename'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($user['lastname'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['department']); ?></td>
                                        <td><?php echo htmlspecialchars($user['year_level'] ?? ''); ?></td>

                                        <td>
                                            <?php if ($user['role'] == 'admin'): ?>
                                                <span class="badge bg-danger">Admin</span>
                                            <?php elseif ($user['role'] == 'moderator'): ?>
                                                <span class="badge bg-warning text-dark">Moderator</span>
                                            <?php else: ?>
                                                <span class="badge bg-info text-dark">Student</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if ($user['is_online'] == 1): ?>
                                                <span class="badge bg-success">Online</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Offline</span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-end">
                                            <button class="btn btn-sm btn-outline-primary me-1"
                                                data-bs-toggle="modal" data-bs-target="#editUserModal"
                                                data-id="<?php echo $user['id']; ?>"
                                                data-school-id="<?php echo htmlspecialchars($user['school_id']); ?>"
                                                data-firstname="<?php echo htmlspecialchars($user['firstname'] ?? ''); ?>"
                                                data-middlename="<?php echo htmlspecialchars($user['middlename'] ?? ''); ?>"
                                                data-lastname="<?php echo htmlspecialchars($user['lastname'] ?? ''); ?>"
                                                data-email="<?php echo htmlspecialchars($user['email']); ?>"
                                                data-department="<?php echo htmlspecialchars($user['department']); ?>"
                                                data-year-level="<?php echo htmlspecialchars($user['year_level'] ?? ''); ?>"
                                                data-role="<?php echo htmlspecialchars($user['role']); ?>">
                                                Edit
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger"
                                                data-bs-toggle="modal" data-bs-target="#deleteUserModal"
                                                data-id="<?php echo $user['id']; ?>"
                                                data-email="<?php echo htmlspecialchars($user['email']); ?>">
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($dbConnected): ?>
                <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4 mt-4" aria-labelledby="voterRegistryHeading">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-3">
                        <div>
                            <h2 class="h5 mb-1" id="voterRegistryHeading">Voter Registry</h2>
                            <p class="text-muted small mb-0">Imported voter details are stored separately from login accounts and synchronized for student users.</p>
                        </div>
                        <select id="voterCollegeFilter" class="form-select form-select-sm" aria-label="Filter voter registry by college" style="max-width: 320px;">
                            <option value="all">All colleges / departments</option>
                            <?php foreach ($allColleges as $college): ?>
                                <option value="<?php echo htmlspecialchars($college['name']); ?>"><?php echo htmlspecialchars($college['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php if (empty($voterRegistry)): ?>
                        <p class="text-muted mb-0">No voter records are currently registered.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border text-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Student_id</th>
                                        <th>First Name</th>
                                        <th>Middle Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>College / Department</th>
                                        <th>Year Level</th>
                                    </tr>
                                </thead>
                                <tbody id="voterRegistryRows">
                                    <?php foreach ($voterRegistry as $voter): ?>
                                        <tr data-college="<?php echo htmlspecialchars($voter['department']); ?>">
                                            <td><?php echo htmlspecialchars($voter['Student_id']); ?></td>
                                            <td><?php echo htmlspecialchars($voter['firstname']); ?></td>
                                            <td><?php echo htmlspecialchars($voter['middlename']); ?></td>
                                            <td><?php echo htmlspecialchars($voter['lastname']); ?></td>
                                            <td><?php echo htmlspecialchars($voter['email']); ?></td>
                                            <td><?php echo htmlspecialchars($voter['department']); ?></td>
                                            <td><?php echo htmlspecialchars($voter['year_level'] ?? ''); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

        </main>
    </div>

    <?php include '../components/actions_modal.php'; ?>
    <?php include '../components/logout_modal.php'; ?>
    <div class="modal fade" id="addCollegeModal" tabindex="-1" aria-labelledby="addCollegeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header text-white" style="background-color: #48672F;">
                        <h5 class="modal-title" id="addCollegeModalLabel">Register College / Department</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <label class="form-label" for="collegeName">College / department name</label>
                        <input class="form-control mb-3" id="collegeName" name="college_name" maxlength="100" required>
                        <label class="form-label" for="collegeCode">Abbreviation (optional)</label>
                        <input class="form-control" id="collegeCode" name="college_code" maxlength="30">
                        <div class="form-text">Registered entries become available for voter, election, and college-filter lists.</div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_college" class="btn text-white" style="background-color: #48672F;">Register</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="importVotersModal" tabindex="-1" aria-labelledby="importVotersModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-header text-white" style="background-color: #48672F;">
                        <h5 class="modal-title" id="importVotersModalLabel">Import Voter List</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Upload an Excel workbook or CSV with these required headers: <code>Student_id,firstname,lastname,email,department</code>. You may also include <code>middlename</code> and <code>year_level</code>. The legacy header <code>school_id</code> is accepted; department must match a registered college. In Excel, keep the header row first and format Student_id cells as text to preserve leading zeros.</p>
                        <a href="data:text/csv;charset=utf-8,Student_id%2Cfirstname%2Cmiddlename%2Clastname%2Cemail%2Cdepartment%2Cyear_level%0A" download="voter-list-template.csv" class="btn btn-sm btn-outline-secondary mb-3">Download CSV template</a>
                        <input class="form-control" type="file" name="voter_csv" accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required>
                        <div class="form-text">The first worksheet is imported. Every new voter account gets the default password <code>123456</code> and must change it at first login. The password is stored as a hash.</div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="import_voters" class="btn text-white" style="background-color: #48672F;">Import Voters</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const editUserModal = document.getElementById('editUserModal');
        if (editUserModal) {
            editUserModal.addEventListener('show.bs.modal', (event) => {
                const button = event.relatedTarget;
                document.getElementById('edit_id').value = button.dataset.id;
                document.getElementById('edit_school_id').value = button.dataset.schoolId;
                document.getElementById('edit_firstname').value = button.dataset.firstname;
                document.getElementById('edit_lastname').value = button.dataset.lastname;
                document.getElementById('edit_email').value = button.dataset.email;
                document.getElementById('edit_department').value = button.dataset.department;
                document.getElementById('edit_year_level').value = button.dataset.yearLevel || '';
                document.getElementById('edit_role').value = button.dataset.role;
            });
        }

        function filterUsers() {
            const role = document.getElementById('roleFilter').value;
            const college = document.getElementById('collegeFilter').value;
            document.querySelectorAll('tbody tr[data-role]').forEach((row) => {
                row.hidden = (role !== 'all' && row.dataset.role !== role)
                    || (college !== 'all' && row.dataset.college !== college);
            });
        }
        document.getElementById('roleFilter')?.addEventListener('change', filterUsers);
        document.getElementById('collegeFilter')?.addEventListener('change', filterUsers);

        document.getElementById('voterCollegeFilter')?.addEventListener('change', (event) => {
            const college = event.target.value;
            document.querySelectorAll('#voterRegistryRows tr').forEach((row) => {
                row.hidden = college !== 'all' && row.dataset.college !== college;
            });
        });

        const downloadCredentials = document.getElementById('downloadCredentials');
        if (downloadCredentials) {
            downloadCredentials.addEventListener('click', () => {
                const rows = Array.from(document.querySelectorAll('#credentialsTable tr')).map((row) =>
                    Array.from(row.cells).map((cell) => '"' + cell.textContent.trim().replace(/"/g, '""') + '"').join(',')
                );
                const link = document.createElement('a');
                link.href = URL.createObjectURL(new Blob([rows.join('\r\n')], { type: 'text/csv;charset=utf-8' }));
                link.download = 'voter-credentials.csv';
                link.click();
                URL.revokeObjectURL(link.href);
            });
        }
    </script>

</body>

</html>