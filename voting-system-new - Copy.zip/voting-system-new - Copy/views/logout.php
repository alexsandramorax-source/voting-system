<?php
session_start();

// Include your database connection (adjust path if your connection file is elsewhere)
require '../connection.php'; 
require '../models/user.php';

if (isset($_SESSION['user_id'])) {
    $user_id = (int) $_SESSION['user_id'];
    if (!setUserOffline($conn, $user_id, session_id())) {
        error_log('Voting system logout could not clear the stored session for user ' . $user_id);
    }
}

session_unset();
if (ini_get('session.use_cookies')) {
    $cookie = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $cookie['path'],
        $cookie['domain'],
        $cookie['secure'],
        $cookie['httponly']
    );
}
session_destroy();

header("Location: login.php?message=logged_out");
exit();
?>