<?php require '../../viewmodels/shared/dashboard_viewmodel.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($appSettings['system_name']); ?> - <?php echo htmlspecialchars(ucfirst($_SESSION['role'])); ?> Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="../../assets/style.css">
    <style>
        .dashboard-stat-link { display: block; height: 100%; text-decoration: none; color: inherit; }
        .dashboard-stat-link .card { transition: transform 0.15s ease, box-shadow 0.15s ease; }
        .dashboard-stat-link:hover .card, .dashboard-stat-link:focus-visible .card {
            transform: translateY(-2px);
            box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .12) !important;
        }
        .dashboard-stat-link:focus-visible { outline: 3px solid #48672F; outline-offset: 3px; border-radius: .5rem; }
    </style>

    <!-- <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar-bg {
            background-color: #48672F !important;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-link:hover,
        .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
        }

        .stat-card-icon {
            font-size: 3rem;
            color: rgba(72, 103, 47, 0.2);
        }
    </style> -->
</head>

<body class="vh-100 overflow-hidden d-flex flex-column flex-md-row">

    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0" tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width: 250px;">

        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3 p-md-3">
            <a href="#" class="d-none d-md-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none px-2">
                <span class="fs-4 fw-bold"><?php echo htmlspecialchars($appSettings['system_name']); ?></span>
            </a>
            <hr class="d-none d-md-block">

            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="#" class="nav-link active" aria-current="page">
                        <span class="material-symbols-outlined">Home</span>
                        Home
                    </a>
                </li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="../admin/view_users.php" class="nav-link">
                            <span class="material-symbols-outlined">groups</span>
                            View Users
                        </a>
                    </li>
                    <li>
                        <a href="../admin/profile_correction_requests.php" class="nav-link">
                            <span class="material-symbols-outlined">manage_accounts</span>
                            Profile Requests
                        </a>
                    </li>
                    <li>
                        <a href="../admin/view_departments.php" class="nav-link">
                            <span class="material-symbols-outlined">domain</span>
                            Departments
                        </a>
                    </li>
                    <li>
                        <a href="../admin/view_elections.php" class="nav-link">
                            <span class="material-symbols-outlined">how_to_vote</span>
                            Elections
                        </a>
                    </li>
                <?php endif; ?>
                <li>
                    <a href="../shared/view_candidates.php" class="nav-link">
                        <span class="material-symbols-outlined">person</span>
                        Candidates
                    </a>
                </li>
                <li>
                    <a href="reports.php" class="nav-link">
                        <span class="material-symbols-outlined">analytics</span>
                        Reports
                    </a>
                </li>
                <li>
                    <a href="results.php" class="nav-link">
                        <span class="material-symbols-outlined">emoji_events</span>
                        Results
                    </a>
                </li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <li>
                        <a href="../admin/settings.php" class="nav-link">
                            <span class="material-symbols-outlined">settings</span>
                            Settings
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <div class="w-100 d-flex flex-column overflow-auto">

        <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">

                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>

                <span class="navbar-brand mb-0 h1 fw-bold fs-5 fs-md-4 text-truncate">Dashboard Overview</span>

                <div class="d-flex align-items-center ms-auto">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="topbarUserDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="material-symbols-outlined me-1 me-md-2 text-muted">account_circle</span>
                            <strong class="d-none d-sm-inline"><?php echo htmlspecialchars($dashboardUserName !== '' ? $dashboardUserName : ucfirst($_SESSION['role'])); ?></strong>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="topbarUserDropdown">
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2 text-danger fw-bold" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                    <span class="material-symbols-outlined" style="font-size: 1.2rem;">logout</span> Sign out
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container-fluid p-3 p-md-4">

            <div class="p-4 p-md-5 mb-4 bg-white rounded-3 shadow-sm border">
                <div class="container-fluid py-2 px-0">
                    <h1 class="display-6 fw-bold text-dark fs-3 fs-md-1">
                        Welcome<?php echo $dashboardUserName !== '' ? ', ' . htmlspecialchars($dashboardUserName) : ''; ?>
                    </h1>
                    <p class="col-md-8 fs-6 fs-md-5 text-muted">
                        <?php echo htmlspecialchars($appSettings['institution_name']); ?> · Current voter registration and election activity.
                        <?php if ($appSettings['support_email'] !== ''): ?>
                            <a href="mailto:<?php echo htmlspecialchars($appSettings['support_email']); ?>" class="text-muted">Contact support</a>
                        <?php endif; ?>
                    </p>
                </div>

                <?php if (!$dbConnected): ?>
                    <div class="alert alert-danger mb-0" role="alert">
                        Dashboard information could not be loaded: <?php echo htmlspecialchars($dbError); ?>
                    </div>
                <?php else: ?>
                    <div class="row g-3 g-md-4 mt-2">
                        <div class="col-12 col-sm-6 col-xl-3">
                            <a class="dashboard-stat-link" href="<?php echo ($_SESSION['role'] ?? '') === 'admin' ? '../admin/view_users.php#voterRegistryHeading' : 'reports.php'; ?>" aria-label="View registered voter information">
                            <div class="card bg-light border-0 shadow-sm h-100">
                                <div class="card-body d-flex justify-content-between align-items-center">
                                    <div>
                                        <h2 class="text-muted text-uppercase fw-bold mb-1 fs-6">Registered Voters</h2>
                                        <p class="mb-0 fw-bold fs-2"><?php echo number_format($dashboardStats['voters']); ?></p>
                                    </div>
                                    <span class="material-symbols-outlined stat-card-icon">groups</span>
                                </div>
                            </div>
                            </a>
                        </div>
                        <div class="col-12 col-sm-6 col-xl-3">
                            <a class="dashboard-stat-link" href="<?php echo ($_SESSION['role'] ?? '') === 'admin' ? '../admin/view_elections.php?status=ongoing' : 'reports.php'; ?>" aria-label="View ongoing elections">
                            <div class="card bg-light border-0 shadow-sm h-100">
                                <div class="card-body d-flex justify-content-between align-items-center">
                                    <div>
                                        <h2 class="text-muted text-uppercase fw-bold mb-1 fs-6">Ongoing Elections</h2>
                                        <p class="mb-0 fw-bold fs-2"><?php echo number_format($dashboardStats['ongoing']); ?></p>
                                    </div>
                                    <span class="material-symbols-outlined stat-card-icon">how_to_vote</span>
                                </div>
                            </div>
                            </a>
                        </div>
                        <div class="col-12 col-sm-6 col-xl-3">
                            <a class="dashboard-stat-link" href="<?php echo ($_SESSION['role'] ?? '') === 'admin' ? '../admin/view_elections.php?status=upcoming' : 'reports.php'; ?>" aria-label="View upcoming elections">
                            <div class="card bg-light border-0 shadow-sm h-100">
                                <div class="card-body d-flex justify-content-between align-items-center">
                                    <div>
                                        <h2 class="text-muted text-uppercase fw-bold mb-1 fs-6">Upcoming Elections</h2>
                                        <p class="mb-0 fw-bold fs-2"><?php echo number_format($dashboardStats['upcoming']); ?></p>
                                    </div>
                                    <span class="material-symbols-outlined stat-card-icon">event</span>
                                </div>
                            </div>
                            </a>
                        </div>
                        <div class="col-12 col-sm-6 col-xl-3">
                            <a class="dashboard-stat-link" href="results.php" aria-label="View completed elections and results">
                            <div class="card bg-light border-0 shadow-sm h-100">
                                <div class="card-body d-flex justify-content-between align-items-center">
                                    <div>
                                        <h2 class="text-muted text-uppercase fw-bold mb-1 fs-6">Completed Elections</h2>
                                        <p class="mb-0 fw-bold fs-2"><?php echo number_format($dashboardStats['completed']); ?></p>
                                    </div>
                                    <span class="material-symbols-outlined stat-card-icon">emoji_events</span>
                                </div>
                            </div>
                            </a>
                        </div>
                    </div>

                    <div class="d-flex flex-wrap gap-2 mt-4">
                        <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                            <a href="../admin/view_users.php" class="btn btn-outline-success">Manage Voters</a>
                            <a href="../admin/view_departments.php" class="btn btn-outline-success">Manage Departments</a>
                            <a href="../admin/view_elections.php" class="btn btn-outline-success">Manage Elections</a>
                        <?php endif; ?>
                        <a href="view_candidates.php" class="btn btn-outline-success">Manage Candidates</a>
                        <a href="reports.php" class="btn btn-outline-success">View Reports</a>
                        <a href="results.php" class="btn btn-outline-success">View Results</a>
                    </div>
                    <?php if ($currentElection !== null): ?>
                        <div class="alert alert-success d-flex flex-wrap align-items-center justify-content-between gap-2 mt-4 mb-0" role="status">
                            <span>
                                <strong>Now ongoing:</strong>
                                <?php echo htmlspecialchars($currentElection['name']); ?>
                                — <?php echo htmlspecialchars($currentElection['department']); ?>
                            </span>
                            <span class="small">Closes <?php echo htmlspecialchars(date('M j, Y g:i A', strtotime($currentElection['close_at']))); ?></span>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <?php if ($dbConnected): ?>
                <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4" aria-labelledby="recentElectionsHeading">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                        <div>
                            <h2 class="h5 fw-bold mb-1" id="recentElectionsHeading">Recent Elections</h2>
                            <p class="text-muted small mb-0">
                                <?php echo number_format($dashboardStats['candidates']); ?> candidates registered across all elections.
                            </p>
                        </div>
                        <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                            <a href="../admin/view_elections.php" class="btn btn-sm btn-outline-success">All Elections</a>
                        <?php endif; ?>
                    </div>
                    <?php if ($recentElections === []): ?>
                        <p class="text-muted mb-0">No elections have been created yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Election</th>
                                        <th>Department</th>
                                        <th>Voting Period</th>
                                        <th>Status</th>
                                        <th>Results</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentElections as $election): ?>
                                        <?php
                                        $statusClass = $election['status'] === 'ongoing'
                                            ? 'success'
                                            : ($election['status'] === 'upcoming' ? 'primary' : 'secondary');
                                        ?>
                                        <tr>
                                            <td class="fw-semibold"><?php echo htmlspecialchars($election['name']); ?></td>
                                            <td><?php echo htmlspecialchars($election['department']); ?></td>
                                            <td>
                                                <span class="d-block"><?php echo htmlspecialchars(date('M j, Y g:i A', strtotime($election['open_at']))); ?></span>
                                                <small class="text-muted">to <?php echo htmlspecialchars(date('M j, Y g:i A', strtotime($election['close_at']))); ?></small>
                                            </td>
                                            <td><span class="badge text-bg-<?php echo $statusClass; ?>"><?php echo htmlspecialchars(ucfirst($election['status'])); ?></span></td>
                                            <td>
                                                <?php if (!empty($election['completed_at'])): ?>
                                                    <a href="results.php?election_id=<?php echo (int) $election['id']; ?>">View results</a>
                                                <?php else: ?>
                                                    <span class="text-muted">Not finalized</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        </main>
    </div>

    <?php include '../components/logout_modal.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>