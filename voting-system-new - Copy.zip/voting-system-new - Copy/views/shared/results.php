<?php
require '../../viewmodels/shared/view_results_viewmodel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SBO Voting System - Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0">
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body class="bg-dashboard vh-100 overflow-hidden d-flex flex-column flex-md-row">
    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0"
         tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width:250px">
        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3">
            <a href="dashboard.php" class="d-none d-md-flex align-items-center me-md-auto text-white text-decoration-none px-2"><span class="fs-4 fw-bold">Voting System</span></a>
            <hr class="d-none d-md-block">
            <ul class="nav nav-pills flex-column mb-auto">
                <?php if (($_SESSION['role'] ?? '') === 'student'): ?>
                    <li><a href="../student/dashboard.php" class="nav-link"><span class="material-symbols-outlined">how_to_vote</span> Elections</a></li>
                    <li><a href="results.php" class="nav-link active" aria-current="page"><span class="material-symbols-outlined">emoji_events</span> Results</a></li>
                    <li><a href="../student/settings.php?section=profile" class="nav-link"><span class="material-symbols-outlined">manage_accounts</span> Profile Request</a></li>
                    <li><a href="../student/settings.php" class="nav-link"><span class="material-symbols-outlined">settings</span> Settings</a></li>
                <?php else: ?>
                <li><a href="dashboard.php" class="nav-link"><span class="material-symbols-outlined">home</span> Home</a></li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <li><a href="../admin/view_users.php" class="nav-link"><span class="material-symbols-outlined">groups</span> View Users</a></li>
                    <li><a href="../admin/profile_correction_requests.php" class="nav-link"><span class="material-symbols-outlined">manage_accounts</span> Profile Requests</a></li>
                    <li><a href="../admin/view_departments.php" class="nav-link"><span class="material-symbols-outlined">domain</span> Departments</a></li>
                <?php endif; ?>
                <li><a href="../admin/view_elections.php" class="nav-link"><span class="material-symbols-outlined">how_to_vote</span> Elections</a></li>
                <li><a href="view_candidates.php" class="nav-link"><span class="material-symbols-outlined">person</span> Candidates</a></li>
                <li><a href="reports.php" class="nav-link"><span class="material-symbols-outlined">analytics</span> Reports</a></li>
                <li><a href="results.php" class="nav-link active" aria-current="page"><span class="material-symbols-outlined">emoji_events</span> Results</a></li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <li><a href="../admin/settings.php" class="nav-link"><span class="material-symbols-outlined">settings</span> Settings</a></li>
                <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <div class="w-100 d-flex flex-column overflow-auto">
        <nav class="navbar navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">
                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>
                <span class="navbar-brand mb-0 h1 fw-bold fs-5">Election Results</span>
                <span class="ms-auto fw-semibold"><?php echo htmlspecialchars(trim(($_SESSION['firstname'] ?? '') . ' ' . ($_SESSION['middlename'] ?? '') . ' ' . ($_SESSION['lastname'] ?? ''))); ?></span>
            </div>
        </nav>

        <main class="container-fluid p-3 p-md-4">
            <?php if ($dbError !== ''): ?>
                <div class="alert alert-danger">Unable to load election results: <?php echo htmlspecialchars($dbError); ?></div>
            <?php elseif ($completedElections === []): ?>
                <section class="bg-white rounded-3 shadow-sm border p-4 text-center">
                    <span class="material-symbols-outlined text-muted" style="font-size:3rem">emoji_events</span>
                    <h1 class="h4 fw-bold mt-2">No completed elections yet</h1>
                    <p class="text-muted mb-0">After an election closes, an administrator can mark it complete from Reports. Its winners and other results will appear here.</p>
                </section>
            <?php else: ?>
                <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
                        <div>
                            <h1 class="h4 fw-bold mb-1">Final Results</h1>
                            <p class="text-muted mb-0">Winners and candidate vote totals from elections declared complete in Reports.</p>
                        </div>
                        <form method="GET" action="results.php" class="d-flex align-items-center gap-2">
                            <label class="form-label mb-0 text-nowrap" for="resultElection">Election</label>
                            <select id="resultElection" class="form-select" name="election_id" onchange="this.form.submit()">
                                <?php foreach ($completedElections as $election): ?>
                                    <option value="<?php echo (int) $election['id']; ?>" <?php echo $selectedElection && (int) $selectedElection['id'] === (int) $election['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($election['name'] . ' — ' . $election['department']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </div>

                    <?php if ($selectedElection): ?>
                        <div class="alert alert-success d-flex align-items-center gap-2">
                            <span class="material-symbols-outlined">verified</span>
                            <span><strong><?php echo htmlspecialchars($selectedElection['name']); ?></strong> · <?php echo htmlspecialchars($selectedElection['department']); ?> · Declared complete <?php echo htmlspecialchars($selectedElection['completed_at']); ?></span>
                        </div>

                        <?php if ($positionResults === []): ?>
                            <div class="alert alert-secondary mb-0">No candidates or vote totals were recorded for this election.</div>
                        <?php else: ?>
                            <?php foreach ($positionResults as $result): ?>
                                <section class="border rounded-3 mb-3 overflow-hidden">
                                    <h2 class="h6 fw-bold bg-light border-bottom p-3 mb-0"><?php echo htmlspecialchars($result['position']); ?></h2>
                                    <?php if ($result['candidates'] === []): ?>
                                        <p class="p-3 mb-0 text-muted">No candidates were registered for this position.</p>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table class="table table-hover align-middle mb-0">
                                                <thead>
                                                    <tr><th class="ps-3">Candidate</th><th>Votes</th><th>Result</th></tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($result['candidates'] as $candidate): ?>
                                                        <tr>
                                                            <td class="ps-3 fw-semibold"><?php echo htmlspecialchars($candidate['name'] ?: 'Unnamed candidate'); ?></td>
                                                            <td><?php echo number_format($candidate['votes']); ?></td>
                                                            <td>
                                                                <?php if ($candidate['standing'] === 'Winner'): ?>
                                                                    <span class="badge bg-success">Winner</span>
                                                                <?php elseif ($candidate['standing'] === 'Loser'): ?>
                                                                    <span class="badge bg-secondary">Loser</span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-warning text-dark">No votes</span>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </section>
                            <?php endforeach; ?>
                            <p class="small text-muted mb-0">Candidates tied for the highest vote count are all listed as winners. Positions where all candidates received zero votes have no winner.</p>
                        <?php endif; ?>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
