<?php
require '../../viewmodels/student/view_student_viewmodel.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SBO Voting System - Elections</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="../../assets/style.css">
    <style>
        .position-card > summary,
        .election-card > summary {
            list-style: none;
            cursor: pointer;
        }
        .position-card > summary::-webkit-details-marker,
        .election-card > summary::-webkit-details-marker {
            display: none;
        }
        .position-toggle {
            transition: transform 0.18s ease;
        }
        .position-card[open] .position-toggle {
            transform: rotate(180deg);
        }
        .dashboard-candidate-card {
            min-height: 100%;
            border: 2px solid #dee2e6;
            border-radius: 0.6rem;
            padding: 0.85rem 1rem;
            cursor: pointer;
            transition: border-color 0.18s, background-color 0.18s;
        }
        .dashboard-candidate-card:hover,
        .dashboard-candidate-card.selected {
            border-color: #48672F;
            background-color: rgba(72, 103, 47, 0.08);
        }
        .dashboard-candidate-card input[type="radio"] {
            accent-color: #48672F;
        }
    </style>
</head>

<body class="bg-dashboard vh-100 overflow-hidden d-flex flex-column flex-md-row">

    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0"
         tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width: 250px;">

        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white"
                    data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3">
            <a href="#" class="d-none d-md-flex align-items-center me-md-auto text-white text-decoration-none px-2">
                <span class="fs-4 fw-bold">Voting System</span>
            </a>
            <hr class="d-none d-md-block">

            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link active" aria-current="page">
                        <span class="material-symbols-outlined">how_to_vote</span>
                        Elections
                    </a>
                </li>
                <li>
                    <a href="settings.php" class="nav-link">
                        <span class="material-symbols-outlined">settings</span>
                        Settings
                    </a>
                </li>
                <li>
                    <a href="../shared/results.php" class="nav-link">
                        <span class="material-symbols-outlined">emoji_events</span>
                        Results
                    </a>
                </li>
                <li>
                    <a href="settings.php?section=profile" class="nav-link">
                        <span class="material-symbols-outlined">manage_accounts</span>
                        Profile Request
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Area -->
    <div class="w-100 d-flex flex-column overflow-auto">

        <!-- Topbar -->
        <nav class="navbar navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">

                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button"
                        data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>

                <span class="navbar-brand mb-0 h1 fw-bold fs-5 fs-md-4 text-truncate">My Elections</span>

                <div class="d-flex align-items-center ms-auto">
                    <div class="dropdown">
                        <!-- Display the logged-in student's full name from session -->
                        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle"
                           id="topbarUserDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="material-symbols-outlined me-1 me-md-2 text-muted">account_circle</span>
                            <strong class="d-none d-sm-inline">
                                <?php echo htmlspecialchars(trim("$studentFirstname $studentMiddlename $studentLastname")); ?>
                            </strong>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="topbarUserDropdown">
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2 text-danger fw-bold"
                                   href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                    <span class="material-symbols-outlined" style="font-size: 1.2rem;">logout</span>
                                    Sign out
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <main class="container-fluid p-3 p-md-4">

            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo htmlspecialchars($messageType); ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (!$dbConnected): ?>

                <!-- Database connection error state -->
                <div class="d-flex flex-column justify-content-center align-items-center bg-white border rounded shadow-sm p-4 p-md-5 mt-4 text-center" style="min-height: 60vh;">
                    <span class="material-symbols-outlined text-danger mb-3" style="font-size: 5rem;">database_off</span>
                    <h2 class="display-6 fw-bold text-dark mb-2 fs-3 fs-md-2">Unable to connect to database</h2>
                    <p class="text-danger small mb-5 bg-light p-3 border rounded w-100" style="max-width: 600px; word-wrap: break-word;">
                        <strong>System Error:</strong> <?php echo htmlspecialchars($dbError); ?>
                    </p>
                    <button onclick="window.location.reload();" class="btn btn-lg text-white d-flex align-items-center gap-2 px-4 px-md-5 py-2 py-md-3 shadow" style="background-color: #6c757d; border-radius: 50px;">
                        <span class="material-symbols-outlined fs-3">refresh</span>
                        <span class="fs-5 fs-md-4">Reload Page</span>
                    </button>
                </div>

            <?php elseif (!$hasElections): ?>

                <!-- No active elections for this student's department -->
                <div class="d-flex flex-column justify-content-center align-items-center bg-white border rounded shadow-sm p-4 p-md-5 mt-4 text-center" style="min-height: 60vh;">
                    <span class="material-symbols-outlined text-muted mb-3" style="font-size: 5rem;">how_to_vote</span>
                    <h2 class="display-6 fw-bold text-dark mb-2 fs-3 fs-md-2">No Active Elections</h2>
                    <p class="text-muted mb-0 fs-6 fs-md-5">
                        There are no ongoing elections for
                        <strong><?php echo htmlspecialchars($studentDepartment); ?></strong>
                        at the moment.
                    </p>
                    <p class="text-muted small mt-1">Check back later or contact your department SBO Office</p>
                </div>

            <?php else: ?>

                <!-- Welcome header -->
                <div class="bg-white rounded-3 shadow-sm border p-3 p-md-4 mb-4">
                    <div class="d-flex align-items-center gap-3">
                        <span class="material-symbols-outlined text-theme" style="font-size: 2.5rem;">how_to_vote</span>
                        <div>
                            <h5 class="fw-bold mb-0">
                                Welcome, <?php echo htmlspecialchars($studentFirstname); ?>!
                            </h5>
                            <p class="text-muted small mb-0">
                                The following
                                <?php echo count($ongoingElections) === 1 ? 'election is' : 'elections are'; ?>
                                currently open for <strong><?php echo htmlspecialchars($studentDepartment); ?></strong>.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="alert border-0 mb-4 d-flex align-items-start gap-2 py-3"
                     style="background-color: rgba(72, 103, 47, 0.08); color: #3a5525;">
                    <span class="material-symbols-outlined mt-1" style="font-size: 1.2rem;">info</span>
                    <div>Open an election, then open a position to see all its candidates together. Choose one candidate or abstain for each position.</div>
                </div>

                <!-- Election cards and ballot choices -->
                <div class="d-flex flex-column gap-3">
                    <?php foreach ($ongoingElections as $election): ?>
                    <?php
                        $electionId = (int) $election['id'];
                        $positionGroups = $candidatesByElection[$electionId] ?? [];
                    ?>
                    <details class="election-card bg-white rounded-3 shadow-sm border overflow-hidden">
                        <summary class="d-flex align-items-center justify-content-between gap-3 p-3 p-md-4">
                            <span>
                                <span class="d-block fw-bold fs-5 text-dark"><?php echo htmlspecialchars($election['name']); ?></span>
                                <span class="text-muted small"><?php echo htmlspecialchars($election['department']); ?> · Closes <?php echo date('M d, Y h:i A', strtotime($election['close_at'])); ?></span>
                            </span>
                            <?php if (isset($submittedElections[$electionId])): ?>
                                <span class="badge bg-success flex-shrink-0">Ballot submitted</span>
                            <?php else: ?>
                                <span class="badge bg-primary flex-shrink-0">Open election</span>
                            <?php endif; ?>
                        </summary>

                        <div class="border-top p-3 p-md-4">
                            <?php if (isset($submittedElections[$electionId])): ?>
                                <div class="alert alert-success mb-0">
                                    You have already submitted your ballot for this election.
                                    <a class="alert-link" href="receipt.php?election_id=<?php echo $electionId; ?>">View your receipt</a>.
                                </div>
                            <?php elseif (empty($positionGroups)): ?>
                                <div class="alert alert-secondary mb-0">Candidates have not been added to this election yet.</div>
                            <?php else: ?>
                                <div class="d-flex flex-column gap-3">
                                    <?php
                                    $positionIndex = 0;
                                    $totalPositions = count($positionGroups);
                                    foreach ($positionGroups as $position => $candidates):
                                        $positionIndex++;
                                        $fieldName = 'vote[' . htmlspecialchars($position, ENT_QUOTES, 'UTF-8') . ']';
                                    ?>
                                        <details class="position-card border rounded-3 overflow-hidden" <?php echo $positionIndex === 1 ? 'open' : ''; ?>>
                                            <summary class="d-flex justify-content-between align-items-center gap-3 px-3 py-3" style="background-color: rgba(72, 103, 47, 0.08);">
                                                <span>
                                                    <strong class="d-block text-dark"><?php echo htmlspecialchars($position); ?></strong>
                                                    <span class="small text-muted"><?php echo count($candidates); ?> candidate<?php echo count($candidates) === 1 ? '' : 's'; ?></span>
                                                </span>
                                                <span class="material-symbols-outlined position-toggle text-success">expand_more</span>
                                            </summary>
                                            <div class="p-3">
                                                <div class="row g-3">
                                                    <?php foreach ($candidates as $candidate): ?>
                                                        <div class="col-12 col-md-6 col-xl-4">
                                                            <label class="dashboard-candidate-card d-flex gap-3 w-100">
                                                                <input type="radio" form="dashboardBallotForm-<?php echo $electionId; ?>" name="<?php echo $fieldName; ?>"
                                                                    value="<?php echo (int) $candidate['id']; ?>" required>
                                                                <span class="overflow-hidden">
                                                                    <span class="badge text-bg-light border mb-2"><?php echo htmlspecialchars($candidate['party_list']); ?></span>
                                                                    <span class="d-block fw-bold text-dark"><?php echo htmlspecialchars(trim(implode(' ', array_filter([$candidate['firstname'], $candidate['middlename'], $candidate['lastname']], function ($part) { return trim((string) $part) !== ''; })))); ?></span>
                                                                    <span class="d-block text-muted small"><?php echo htmlspecialchars($candidate['school_id']); ?></span>
                                                                    <span class="d-block text-muted small">
                                                                        Year level: <?php echo htmlspecialchars(trim((string) ($candidate['year_level'] ?? '')) ?: 'Not provided'); ?>
                                                                    </span>
                                                                    <?php if (!empty($candidate['candidate_department'])): ?>
                                                                        <span class="d-block text-muted small">College: <?php echo htmlspecialchars($candidate['candidate_department']); ?></span>
                                                                    <?php endif; ?>
                                                                    <?php if (!empty($candidate['contact_number'])): ?>
                                                                        <span class="d-block text-muted small mb-1">Contact: <?php echo htmlspecialchars($candidate['contact_number']); ?></span>
                                                                    <?php endif; ?>
                                                                    <?php if (!empty($candidate['bio'])): ?>
                                                                        <span class="d-block text-muted small"><?php echo htmlspecialchars($candidate['bio']); ?></span>
                                                                    <?php endif; ?>
                                                                </span>
                                                            </label>
                                                        </div>
                                                    <?php endforeach; ?>
                                                    <div class="col-12 col-md-6 col-xl-4">
                                                        <label class="dashboard-candidate-card d-flex align-items-center gap-3 w-100">
                                                            <input type="radio" form="dashboardBallotForm-<?php echo $electionId; ?>" name="<?php echo $fieldName; ?>" value="abstain" required>
                                                            <span>
                                                                <span class="d-block fw-bold text-muted">Abstain</span>
                                                                <span class="small text-muted">I choose not to vote for this position.</span>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </details>
                                    <?php endforeach; ?>
                                </div>

                                <form method="POST" id="dashboardBallotForm-<?php echo $electionId; ?>" class="mt-4">
                                    <input type="hidden" name="submit_ballot" value="1">
                                    <input type="hidden" name="election_id" value="<?php echo $electionId; ?>">
                                    <button type="button" class="btn text-white fw-semibold d-flex align-items-center justify-content-center gap-2"
                                        data-review-ballot="<?php echo $electionId; ?>" style="background-color: #48672F;">
                                        <span class="material-symbols-outlined">how_to_vote</span> Review and Submit Ballot
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </details>
                    <?php endforeach; ?>
                </div>

            <?php endif; ?>

        </main>
    </div>

    <?php include '../components/logout_modal.php'; ?>

    <div class="modal fade" id="confirmDashboardBallotModal" tabindex="-1" aria-labelledby="confirmDashboardBallotTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold" id="confirmDashboardBallotTitle">Confirm Ballot Submission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center py-4">
                    <span class="material-symbols-outlined mb-3" style="font-size: 3.5rem; color: #48672F;">how_to_vote</span>
                    <p class="mb-1">Your ballot is final once submitted and cannot be changed.</p>
                </div>
                <div class="modal-footer border-0 d-flex justify-content-center bg-light rounded-bottom">
                    <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">Go Back</button>
                    <button type="button" id="confirmDashboardBallotSubmit" class="btn text-white px-4 fw-bold" style="background-color: #48672F;">Yes, Submit My Vote</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.dashboard-candidate-card input[type="radio"]').forEach((radio) => {
            radio.addEventListener('change', () => {
                document.querySelectorAll(`input[name="${CSS.escape(radio.name)}"]`).forEach((choice) => {
                    choice.closest('.dashboard-candidate-card').classList.remove('selected');
                });
                radio.closest('.dashboard-candidate-card').classList.add('selected');
            });
        });

        let ballotFormToSubmit = null;
        const ballotModal = document.getElementById('confirmDashboardBallotModal');
        const ballotConfirmation = ballotModal
            ? bootstrap.Modal.getOrCreateInstance(ballotModal)
            : null;

        document.querySelectorAll('[data-review-ballot]').forEach((button) => {
            button.addEventListener('click', () => {
                const electionId = button.dataset.reviewBallot;
                const form = document.getElementById(`dashboardBallotForm-${electionId}`);
                const electionCard = button.closest('.election-card');
                const positionCards = Array.from(electionCard.querySelectorAll('.position-card'));
                const incompleteCard = positionCards.find((card) =>
                    !card.querySelector('input[type="radio"]:checked')
                );

                if (incompleteCard) {
                    electionCard.open = true;
                    incompleteCard.open = true;
                    incompleteCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    const choice = incompleteCard.querySelector('input[type="radio"]');
                    if (choice) {
                        choice.focus({ preventScroll: true });
                        choice.reportValidity();
                    }
                    return;
                }

                ballotFormToSubmit = form;
                ballotConfirmation.show();
            });
        });

        document.getElementById('confirmDashboardBallotSubmit')?.addEventListener('click', () => {
            if (ballotFormToSubmit) {
                ballotFormToSubmit.requestSubmit();
            }
        });
    </script>
</body>

</html>