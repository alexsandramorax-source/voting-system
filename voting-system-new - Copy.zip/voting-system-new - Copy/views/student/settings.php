<?php
require '../../viewmodels/student/settings_viewmodel.php';

$pageTitles = [
    'home' => 'My Settings',
    'password' => 'Change Password',
    'profile' => 'Request Profile Correction'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitles[$settingsSection]); ?> | Voting System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0">
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body class="bg-dashboard vh-100 overflow-hidden d-flex flex-column flex-md-row">
    <div class="sidebar-bg text-white shadow offcanvas-md offcanvas-start d-flex flex-column flex-shrink-0"
         tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel" style="width:250px">
        <div class="offcanvas-header d-md-none border-bottom border-secondary">
            <h5 class="offcanvas-title fw-bold" id="sidebarMenuLabel">Voting System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column flex-grow-1 p-3">
            <a href="dashboard.php" class="d-none d-md-flex align-items-center me-md-auto text-white text-decoration-none px-2"><span class="fs-4 fw-bold">Voting System</span></a>
            <hr class="d-none d-md-block">
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="dashboard.php" class="nav-link"><span class="material-symbols-outlined">how_to_vote</span> Elections</a></li>
                <li><a href="../shared/results.php" class="nav-link"><span class="material-symbols-outlined">emoji_events</span> Results</a></li>
                <li><a href="settings.php?section=profile" class="nav-link<?php echo $settingsSection === 'profile' ? ' active' : ''; ?>"<?php echo $settingsSection === 'profile' ? ' aria-current="page"' : ''; ?>><span class="material-symbols-outlined">manage_accounts</span> Profile Request</a></li>
                <li><a href="settings.php" class="nav-link<?php echo $settingsSection === 'profile' ? '' : ' active'; ?>"<?php echo $settingsSection === 'profile' ? '' : ' aria-current="page"'; ?>><span class="material-symbols-outlined">settings</span> Settings</a></li>
            </ul>
        </div>
    </div>
    <div class="w-100 d-flex flex-column overflow-auto">
        <nav class="navbar navbar-light bg-white border-bottom px-3 px-md-4 shadow-sm">
            <div class="container-fluid p-0">
                <button class="navbar-toggler d-md-none border-0 px-1 me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu">
                    <span class="material-symbols-outlined text-dark">menu</span>
                </button>
                <span class="navbar-brand mb-0 h1 fw-bold fs-5"><?php echo htmlspecialchars($pageTitles[$settingsSection]); ?></span>
                <span class="ms-auto fw-semibold"><?php echo htmlspecialchars(trim(($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? '') . ' ' . ($student['lastname'] ?? ''))); ?></span>
            </div>
        </nav>
        <main class="container-fluid p-3 p-md-4">
            <?php if ($dbError !== ''): ?>
                <div class="alert alert-danger">Unable to load your settings: <?php echo htmlspecialchars($dbError); ?></div>
            <?php else: ?>
                <?php if ($message !== ''): ?>
                    <div class="alert alert-<?php echo htmlspecialchars($messageType); ?> alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($message); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($settingsSection !== 'home'): ?>
                    <a href="settings.php" class="btn btn-outline-secondary mb-3">
                        <span class="material-symbols-outlined align-middle">arrow_back</span>
                        Back to Settings
                    </a>
                <?php endif; ?>

                <?php if ($settingsSection === 'home'): ?>
                    <div class="row g-4">
                        <div class="col-12 col-lg-6">
                            <section class="bg-white rounded-3 shadow-sm border p-4 h-100">
                                <span class="material-symbols-outlined text-success" style="font-size:2rem">lock</span>
                                <h1 class="h4 fw-bold mt-2">Password</h1>
                                <p class="text-muted">Update your account password using your current password.</p>
                                <a href="settings.php?section=password" class="btn btn-success">Open password settings</a>
                            </section>
                        </div>
                        <div class="col-12 col-lg-6">
                            <section class="bg-white rounded-3 shadow-sm border p-4 h-100">
                                <span class="material-symbols-outlined text-success" style="font-size:2rem">manage_accounts</span>
                                <h2 class="h4 fw-bold mt-2">Profile information</h2>
                                <p class="text-muted">Submit updates to your Student ID, name, email, college, or year level for administrator review.</p>
                                <a href="settings.php?section=profile" class="btn btn-success">Open profile correction</a>
                            </section>
                        </div>
                        <div class="col-12">
                            <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4">
                                <h2 class="h5 fw-bold">Your current information</h2>
                                <p class="text-muted">This is the profile currently saved to your student account. Pending correction requests do not change it until approved.</p>
                                <div class="row g-3">
                                    <div class="col-12 col-md-4">
                                        <div class="small text-muted">Student ID</div>
                                        <div class="fw-semibold"><?php echo htmlspecialchars($student['school_id']); ?></div>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <div class="small text-muted">Name</div>
                                        <div class="fw-semibold"><?php echo htmlspecialchars(trim($student['firstname'] . ' ' . ($student['middlename'] ?? '') . ' ' . $student['lastname'])); ?></div>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <div class="small text-muted">Email</div>
                                        <div class="fw-semibold"><?php echo htmlspecialchars($student['email']); ?></div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="small text-muted">College / department</div>
                                        <div class="fw-semibold"><?php echo htmlspecialchars($student['department']); ?></div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="small text-muted">Year level</div>
                                        <div class="fw-semibold"><?php echo htmlspecialchars($student['year_level'] ?? 'Not set'); ?></div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <?php if ($studentRequests !== []): ?>
                            <div class="col-12">
                                <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4">
                                    <h2 class="h5 fw-bold">Your correction requests</h2>
                                    <div class="table-responsive">
                                        <table class="table align-middle mb-0">
                                            <thead><tr><th>Submitted</th><th>Requested Student ID</th><th>Requested email</th><th>Status</th><th>Reviewed</th></tr></thead>
                                            <tbody>
                                                <?php foreach ($studentRequests as $request): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($request['created_at']); ?></td>
                                                        <td><?php echo htmlspecialchars($request['requested_student_id']); ?></td>
                                                        <td><?php echo htmlspecialchars($request['requested_email']); ?></td>
                                                        <td><span class="badge bg-<?php echo $request['status'] === 'pending' ? 'warning text-dark' : ($request['status'] === 'approved' ? 'success' : 'secondary'); ?>"><?php echo htmlspecialchars(ucfirst($request['status'])); ?></span></td>
                                                        <td><?php echo htmlspecialchars($request['reviewed_at'] ?? '—'); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </section>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php elseif ($settingsSection === 'password'): ?>
                    <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4" style="max-width:650px">
                        <h1 class="h4 fw-bold">Change password</h1>
                        <p class="text-muted">Your new password must be at least <?php echo (int) $minimumPasswordLength; ?> characters.</p>
                        <form method="post" action="settings.php?section=password">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <div class="mb-3">
                                <label class="form-label" for="currentPassword">Current password</label>
                                <input class="form-control" type="password" id="currentPassword" name="current_password" autocomplete="current-password" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="newPassword">New password</label>
                                <input class="form-control" type="password" id="newPassword" name="new_password" minlength="<?php echo (int) $minimumPasswordLength; ?>" autocomplete="new-password" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="confirmPassword">Confirm new password</label>
                                <input class="form-control" type="password" id="confirmPassword" name="confirm_password" minlength="<?php echo (int) $minimumPasswordLength; ?>" autocomplete="new-password" required>
                            </div>
                            <button class="btn btn-success" type="submit" name="change_password" value="1">Update password</button>
                        </form>
                    </section>
                <?php else: ?>
                    <section class="bg-white rounded-3 shadow-sm border p-3 p-md-4" style="max-width:900px">
                        <h1 class="h4 fw-bold">Request profile correction</h1>
                        <p class="text-muted">Your current profile stays unchanged until an administrator approves your request.</p>
                        <div class="alert alert-light border mb-4">
                            <h2 class="h6 fw-bold">Current information</h2>
                            <div class="row g-2 small">
                                <div class="col-12 col-md-6"><strong>Student ID:</strong> <?php echo htmlspecialchars($student['school_id']); ?></div>
                                <div class="col-12 col-md-6"><strong>Name:</strong> <?php echo htmlspecialchars(trim($student['firstname'] . ' ' . ($student['middlename'] ?? '') . ' ' . $student['lastname'])); ?></div>
                                <div class="col-12 col-md-6"><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></div>
                                <div class="col-12 col-md-6"><strong>College / department:</strong> <?php echo htmlspecialchars($student['department']); ?></div>
                                <div class="col-12 col-md-6"><strong>Year level:</strong> <?php echo htmlspecialchars($student['year_level'] ?? 'Not set'); ?></div>
                            </div>
                        </div>
                        <form method="post" action="settings.php?section=profile">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="studentId">Student ID</label>
                                    <input class="form-control" id="studentId" name="school_id" maxlength="50" value="<?php echo htmlspecialchars($student['school_id']); ?>" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="profileEmail">Email</label>
                                    <input class="form-control" type="email" id="profileEmail" name="email" maxlength="100" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label" for="firstName">First name</label>
                                    <input class="form-control" id="firstName" name="firstname" maxlength="100" value="<?php echo htmlspecialchars($student['firstname']); ?>" required>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label" for="middleName">Middle name</label>
                                    <input class="form-control" id="middleName" name="middlename" maxlength="100" value="<?php echo htmlspecialchars($student['middlename'] ?? ''); ?>">
                                </div>
                                <div class="col-12 col-md-4">
                                    <label class="form-label" for="lastName">Last name</label>
                                    <input class="form-control" id="lastName" name="lastname" maxlength="100" value="<?php echo htmlspecialchars($student['lastname']); ?>" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="department">College / department</label>
                                    <select class="form-select" id="department" name="department" required>
                                        <option value="">Select a college</option>
                                        <?php foreach ($colleges as $college): ?>
                                            <option value="<?php echo htmlspecialchars($college['name']); ?>" <?php echo $student['department'] === $college['name'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($college['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="yearLevel">Year level</label>
                                    <input class="form-control" id="yearLevel" name="year_level" maxlength="30" value="<?php echo htmlspecialchars($student['year_level'] ?? ''); ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label" for="correctionMessage">Note for the administrator (optional)</label>
                                    <textarea class="form-control" id="correctionMessage" name="correction_message" rows="3" maxlength="1000" placeholder="Briefly explain the requested correction"></textarea>
                                </div>
                            </div>
                            <button class="btn btn-success mt-3" type="submit" name="submit_profile_correction" value="1">Submit correction request</button>
                        </form>
                    </section>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
