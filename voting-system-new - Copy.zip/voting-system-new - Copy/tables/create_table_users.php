<?php
require_once '../connection.php';

$sql_create_table_users = "CREATE TABLE users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    school_id VARCHAR(50) NOT NULL,
    firstname VARCHAR(100) NOT NULL,
    middlename VARCHAR(100) NOT NULL DEFAULT '',
    lastname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'moderator', 'admin') DEFAULT 'student',
    is_new TINYINT(1) NOT NULL DEFAULT 0,
    is_online INT(1) DEFAULT 0,
    session_id VARCHAR(255) NULL,
    last_activity DATETIME NULL DEFAULT NULL,
    department VARCHAR(100) NOT NULL,
    year_level VARCHAR(30) NULL DEFAULT NULL
)";

if(mysqli_query($conn, $sql_create_table_users)) {
    echo "Table Users Created!";
}else {
    echo "Error: " . mysqli_errno($conn);
}

$sql_create_table_voters = "CREATE TABLE IF NOT EXISTS voters (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Student_id VARCHAR(50) NOT NULL,
    firstname VARCHAR(100) NOT NULL,
    middlename VARCHAR(100) NOT NULL DEFAULT '',
    lastname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    year_level VARCHAR(30) NULL DEFAULT NULL,
    user_id INT(6) UNSIGNED NULL DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_voter_user (user_id),
    KEY idx_voter_student_id (Student_id),
    KEY idx_voter_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($conn, $sql_create_table_voters)) {
    echo "Table Voters Created!";
} else {
    echo "Error creating voters table: " . mysqli_error($conn);
}