<?php

// Derive election status from timestamps and the force-close flag.
// Uses strtotime() so comparison is numeric, not a fragile string match.
function computeElectionStatus($open_at, $close_at, $is_closed)
{
    if ($is_closed == 1) {
        return 'closed';
    }

    $now = time();
    $open_ts = strtotime($open_at);
    $close_ts = strtotime($close_at);

    if ($now < $open_ts) {
        return 'upcoming';
    }

    if ($now <= $close_ts) {
        return 'ongoing';
    }

    // Past the close time and not force-closed — treat as closed
    return 'closed';
}

function ensureElectionCompletionSchema($conn)
{
    $columns = mysqli_query($conn, "SHOW COLUMNS FROM elections LIKE 'completed_at'");
    if (!$columns) {
        return false;
    }
    if (mysqli_num_rows($columns) === 0) {
        return (bool) mysqli_query($conn, "ALTER TABLE elections ADD COLUMN completed_at DATETIME NULL DEFAULT NULL");
    }
    return true;
}

// Return every election row with a computed status key appended
function getAllElections($conn)
{
    $query = "SELECT * FROM elections ORDER BY open_at DESC";
    $result = mysqli_query($conn, $query);

    $elections = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $row['status'] = computeElectionStatus($row['open_at'], $row['close_at'], $row['is_closed']);
            $elections[]   = $row;
        }
    }

    return $elections;
}

function getCompletedElections($conn)
{
    $result = mysqli_query($conn, "SELECT * FROM elections
        WHERE completed_at IS NOT NULL
        ORDER BY completed_at DESC, open_at DESC");
    if (!$result) {
        return false;
    }
    $elections = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $row['status'] = computeElectionStatus($row['open_at'], $row['close_at'], $row['is_closed']);
        $elections[] = $row;
    }
    return $elections;
}

function declareElectionComplete($conn, $id)
{
    $statement = mysqli_prepare($conn, "SELECT open_at, close_at, is_closed, completed_at
        FROM elections WHERE id = ? LIMIT 1");
    if (!$statement) {
        return ['success' => false, 'message' => 'Unable to check election status: ' . mysqli_error($conn)];
    }
    $id = (int) $id;
    mysqli_stmt_bind_param($statement, 'i', $id);
    if (!mysqli_stmt_execute($statement)) {
        $error = mysqli_stmt_error($statement);
        mysqli_stmt_close($statement);
        return ['success' => false, 'message' => 'Unable to check election status: ' . $error];
    }
    $result = mysqli_stmt_get_result($statement);
    $election = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);

    if (!$election) {
        return ['success' => false, 'message' => 'The selected election was not found.'];
    }
    if (!empty($election['completed_at'])) {
        return ['success' => true, 'message' => 'This election has already been marked complete.'];
    }
    if (computeElectionStatus($election['open_at'], $election['close_at'], $election['is_closed']) !== 'closed') {
        return ['success' => false, 'message' => 'Only a closed election can be declared complete.'];
    }

    $statement = mysqli_prepare($conn, "UPDATE elections SET completed_at = NOW()
        WHERE id = ? AND completed_at IS NULL");
    if (!$statement) {
        return ['success' => false, 'message' => 'Unable to prepare election completion: ' . mysqli_error($conn)];
    }
    mysqli_stmt_bind_param($statement, 'i', $id);
    $success = mysqli_stmt_execute($statement);
    $error = mysqli_stmt_error($statement);
    $updated = mysqli_stmt_affected_rows($statement) === 1;
    mysqli_stmt_close($statement);
    if (!$success) {
        return ['success' => false, 'message' => 'Unable to mark election complete: ' . $error];
    }
    if (!$updated) {
        return ['success' => false, 'message' => 'Election completion could not be saved. Please reload and try again.'];
    }
    return ['success' => true, 'message' => 'Election marked complete. Its winners and results are now available in Results.'];
}

// Return only ongoing elections for a student.
// Matches the student's department exactly OR elections marked University Wide
function getOngoingElectionsForStudent($conn, $department)
{

    $query = "SELECT * FROM elections
              WHERE is_closed  = 0
                AND open_at   <= NOW()
                AND close_at  >= NOW()
                AND (department = '$department' OR department = 'University Wide')
              ORDER BY close_at ASC";

    $result = mysqli_query($conn, $query);

    $elections = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $row['status'] = 'ongoing';
            $elections[] = $row;
        }
    }

    return $elections;
}

// Insert a new election record
function createElection($conn, $name, $department, $open_at, $close_at)
{
    $statement = mysqli_prepare($conn, "INSERT INTO elections
        (name, department, open_at, close_at, firstname, lastname) VALUES (?, ?, ?, ?, '', '')");
    if (!$statement) {
        return false;
    }
    mysqli_stmt_bind_param($statement, 'ssss', $name, $department, $open_at, $close_at);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Update an existing upcoming election — should not be called on ongoing elections
function updateElection($conn, $id, $name, $department, $open_at, $close_at)
{
    $statement = mysqli_prepare($conn, "UPDATE elections
        SET name = ?, department = ?, open_at = ?, close_at = ? WHERE id = ?");
    if (!$statement) {
        return false;
    }
    $id = (int) $id;
    mysqli_stmt_bind_param($statement, 'ssssi', $name, $department, $open_at, $close_at, $id);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Force-close an ongoing election early
function closeElection($conn, $id)
{
    $query = "UPDATE elections SET is_closed = 1 WHERE id = $id";
    return mysqli_query($conn, $query);
}

// Permanently delete an election — only valid for closed elections
function deleteElection($conn, $id)
{
    $query = "DELETE FROM elections WHERE id = $id";
    return mysqli_query($conn, $query);
}