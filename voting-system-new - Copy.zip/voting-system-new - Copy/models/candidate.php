<?php

function ensureCandidatePartyListSchema($conn)
{
    $columns = [];
    $userIdColumnAdded = false;
    $candidateNameColumnsAdded = false;
    $candidateNameColumns = ['firstname', 'middlename', 'lastname'];
    $result = mysqli_query($conn, "SHOW COLUMNS FROM candidates");
    if (!$result) {
        return false;
    }
    while ($column = mysqli_fetch_assoc($result)) {
        $columns[$column['Field']] = true;
    }

    foreach ($candidateNameColumns as $nameColumn) {
        if (!isset($columns[$nameColumn])) {
            if (!mysqli_query(
                $conn,
                "ALTER TABLE candidates ADD COLUMN $nameColumn VARCHAR(100) NOT NULL DEFAULT '' AFTER fullname"
            )) {
                return false;
            }
            $columns[$nameColumn] = true;
            $candidateNameColumnsAdded = true;
        }
    }
    if (!isset($columns['name_parts_migrated'])) {
        if (!mysqli_query(
            $conn,
            "ALTER TABLE candidates ADD COLUMN name_parts_migrated TINYINT(1) NOT NULL DEFAULT 0"
        )) {
            return false;
        }
        if (!mysqli_query($conn, "UPDATE candidates
            SET firstname = SUBSTRING_INDEX(TRIM(fullname), ' ', 1),
                lastname = CASE
                    WHEN LOCATE(' ', TRIM(fullname)) > 0
                    THEN TRIM(SUBSTRING(TRIM(fullname), LOCATE(' ', TRIM(fullname)) + 1))
                    ELSE ''
                END,
                name_parts_migrated = 1")) {
            return false;
        }
    }

    if (!isset($columns['party_list']) && !mysqli_query(
        $conn,
        "ALTER TABLE candidates ADD COLUMN party_list VARCHAR(100) NOT NULL DEFAULT 'Independent' AFTER position"
    )) {
        return false;
    }
    if (!isset($columns['user_id'])) {
        if (!mysqli_query(
            $conn,
            "ALTER TABLE candidates ADD COLUMN user_id INT(6) UNSIGNED NULL DEFAULT NULL AFTER school_id"
        )) {
            return false;
        }
        $userIdColumnAdded = true;
    }

    $users = mysqli_query($conn, "SHOW COLUMNS FROM users");
    if (!$users) {
        return false;
    }
    $userColumns = [];
    $userMiddleNameAdded = false;
    while ($column = mysqli_fetch_assoc($users)) {
        $userColumns[$column['Field']] = true;
    }
    foreach ([
        'middlename' => "ALTER TABLE users ADD COLUMN middlename VARCHAR(100) NOT NULL DEFAULT '' AFTER firstname",
        'year_level' => "ALTER TABLE users ADD COLUMN year_level VARCHAR(30) NULL DEFAULT NULL"
    ] as $userColumn => $alter) {
        if (!isset($userColumns[$userColumn]) && !mysqli_query($conn, $alter)) {
            return false;
        }
        if ($userColumn === 'middlename' && !isset($userColumns[$userColumn])) {
            $userMiddleNameAdded = true;
        }
    }

    if ($userIdColumnAdded && !mysqli_query($conn, "UPDATE candidates c
        INNER JOIN (
            SELECT school_id, MIN(id) AS id
            FROM users
            WHERE role = 'student'
            GROUP BY school_id
            HAVING COUNT(*) = 1
        ) u ON u.school_id = c.school_id
        SET c.user_id = u.id
        WHERE c.user_id IS NULL")) {
        return false;
    }

    if ($candidateNameColumnsAdded || $userMiddleNameAdded) {
        return (bool) mysqli_query($conn, "UPDATE candidates c
        INNER JOIN users u ON u.id = c.user_id
        SET c.firstname = u.firstname, c.middlename = u.middlename, c.lastname = u.lastname,
            c.fullname = TRIM(CONCAT_WS(' ', NULLIF(u.firstname, ''), NULLIF(u.middlename, ''), NULLIF(u.lastname, '')))
        WHERE c.user_id IS NOT NULL");
    }

    return true;
}

// Fetch all candidates for a given election, joined with their election name
function getAllCandidates($conn)
{
    $query = "SELECT c.*, e.name AS election_name
               FROM candidates c
               JOIN elections e ON c.election_id = e.id
               ORDER BY e.name, c.position, c.fullname";
    $result = mysqli_query($conn, $query);

    $candidates = [];
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $candidates[] = $row;
        }
    }
    return $candidates;
}

// Fetch all candidates for a specific election ordered by position then name
function getCandidatesByElection($conn, $election_id)
{
    $query= "SELECT * FROM candidates c
               WHERE c.election_id = $election_id
               ORDER BY c.position, c.fullname";
    $result = mysqli_query($conn, $query);

    $candidates = [];
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $candidates[] = $row;
        }
    }
    return $candidates;
}

// Return candidates grouped by position — used to build the ballot form
function getCandidatesGroupedByPosition($conn, $election_id)
{
    $query = "SELECT c.*, u.year_level, u.department AS candidate_department
               FROM candidates c
               LEFT JOIN users u ON u.id = c.user_id
               WHERE c.election_id = $election_id
               ORDER BY c.position, c.party_list, c.fullname";
    $result = mysqli_query($conn, $query);

    $grouped = [];
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $row['party_list'] = trim($row['party_list'] ?? '') ?: 'Independent';
            $grouped[$row['position']][] = $row;
        }
    }
    return $grouped;
}

// Insert a new candidate record linked to an election
function addCandidate($conn, $election_id, $firstname, $middlename, $lastname, $position, $party_list, $bio, $school_id, $email, $contact_number, $user_id = null)
{
    $fullname = trim(implode(' ', array_filter([$firstname, $middlename, $lastname], function ($part) {
        return trim($part) !== '';
    })));
    $statement = mysqli_prepare($conn, "INSERT INTO candidates
        (election_id, fullname, firstname, middlename, lastname, position, party_list, bio, school_id, user_id, email, contact_number)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$statement) {
        return false;
    }
    $election_id = (int) $election_id;
    mysqli_stmt_bind_param(
        $statement,
        'issssssssiss',
        $election_id,
        $fullname,
        $firstname,
        $middlename,
        $lastname,
        $position,
        $party_list,
        $bio,
        $school_id,
        $user_id,
        $email,
        $contact_number
    );
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Update an existing candidate record by ID
function updateCandidate($conn, $id, $election_id, $firstname, $middlename, $lastname, $position, $party_list, $bio, $school_id, $email, $contact_number, $user_id = null)
{
    $fullname = trim(implode(' ', array_filter([$firstname, $middlename, $lastname], function ($part) {
        return trim($part) !== '';
    })));
    $statement = mysqli_prepare($conn, "UPDATE candidates
        SET election_id = ?, fullname = ?, firstname = ?, middlename = ?, lastname = ?,
            position = ?, party_list = ?, bio = ?, school_id = ?,
            user_id = COALESCE(?, user_id), email = ?, contact_number = ?
        WHERE id = ?");
    if (!$statement) {
        return false;
    }
    $id = (int) $id;
    $election_id = (int) $election_id;
    mysqli_stmt_bind_param(
        $statement,
        'issssssssissi',
        $election_id,
        $fullname,
        $firstname,
        $middlename,
        $lastname,
        $position,
        $party_list,
        $bio,
        $school_id,
        $user_id,
        $email,
        $contact_number,
        $id
    );
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Permanently remove a candidate — admin only
function deleteCandidate($conn, $id)
{
    $query = "DELETE FROM candidates WHERE id = $id";
    return mysqli_query($conn, $query);
}
