<?php

function ensureCollegeSchema($conn)
{
    if (!mysqli_query($conn, "CREATE TABLE IF NOT EXISTS colleges (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        code VARCHAR(30) DEFAULT NULL UNIQUE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")) {
        return false;
    }

    $columns = [];
    $result = mysqli_query($conn, "SHOW COLUMNS FROM users");
    if (!$result) {
        return false;
    }
    while ($column = mysqli_fetch_assoc($result)) {
        $columns[$column['Field']] = strtolower($column['Type']);
    }

    $legacyColleges = [
        'CCS' => 'College of Computer Studies',
        'COE' => 'College of Engineering',
        'CBA' => 'College of Business Administration',
        'CAS' => 'College of Arts and Sciences',
        'CED' => 'College of Education',
        'CRIM' => 'College of Criminology',
        'COHS' => 'College of Health and Sciences'
    ];
    foreach ($legacyColleges as $code => $name) {
        $statement = mysqli_prepare($conn, "INSERT IGNORE INTO colleges (name, code) VALUES (?, ?)");
        if (!$statement) {
            return false;
        }
        mysqli_stmt_bind_param($statement, 'ss', $name, $code);
        $success = mysqli_stmt_execute($statement);
        mysqli_stmt_close($statement);
        if (!$success) {
            return false;
        }
    }

    foreach ([
        'firstname' => "ALTER TABLE users ADD COLUMN firstname VARCHAR(100) NOT NULL DEFAULT ''",
        'middlename' => "ALTER TABLE users ADD COLUMN middlename VARCHAR(100) NOT NULL DEFAULT '' AFTER firstname",
        'lastname' => "ALTER TABLE users ADD COLUMN lastname VARCHAR(100) NOT NULL DEFAULT ''",
        'year_level' => "ALTER TABLE users ADD COLUMN year_level VARCHAR(30) NULL DEFAULT NULL",
        'is_new' => "ALTER TABLE users ADD COLUMN is_new TINYINT(1) NOT NULL DEFAULT 0"
    ] as $column => $statement) {
        if (!isset($columns[$column]) && !mysqli_query($conn, $statement)) {
            return false;
        }
    }
    if (!isset($columns['department'])) {
        return false;
    }
    if ($columns['department'] !== 'varchar(100)' && !mysqli_query($conn, "ALTER TABLE users MODIFY department VARCHAR(100) NOT NULL")) {
        return false;
    }

    foreach ($legacyColleges as $code => $name) {
        foreach (['users', 'elections'] as $table) {
            $tableCheck = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
            if (!$tableCheck) {
                return false;
            }
            if (mysqli_num_rows($tableCheck) === 0) {
                continue;
            }
            $statement = mysqli_prepare($conn, "UPDATE $table SET department = ? WHERE department = ?");
            if (!$statement) {
                return false;
            }
            mysqli_stmt_bind_param($statement, 'ss', $name, $code);
            $success = mysqli_stmt_execute($statement);
            mysqli_stmt_close($statement);
            if (!$success) {
                return false;
            }
        }
    }

    $seed = mysqli_query($conn, "INSERT IGNORE INTO colleges (name)
        SELECT DISTINCT department FROM users
        WHERE department IS NOT NULL AND department <> ''");
    if (!$seed) {
        return false;
    }

    $electionColumns = mysqli_query($conn, "SHOW TABLES LIKE 'elections'");
    if (!$electionColumns || mysqli_num_rows($electionColumns) === 0) {
        return true;
    }

    $seed = mysqli_query($conn, "INSERT IGNORE INTO colleges (name)
        SELECT DISTINCT department FROM elections
        WHERE department IS NOT NULL AND department <> '' AND department <> 'University Wide'");
    return (bool) $seed;
}

function getColleges($conn)
{
    $result = mysqli_query($conn, "SELECT id, name, code FROM colleges ORDER BY name");
    $colleges = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $colleges[] = $row;
        }
    }
    return $colleges;
}

function getCollegesWithUsage($conn)
{
    $result = mysqli_query($conn, "SELECT c.id, c.name, c.code,
        (SELECT COUNT(*) FROM users u WHERE u.department = c.name) AS user_count,
        (SELECT COUNT(*) FROM elections e WHERE e.department = c.name) AS election_count
        FROM colleges c
        ORDER BY c.name");
    $colleges = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $colleges[] = $row;
        }
    }
    return $colleges;
}

function addCollege($conn, $name, $code)
{
    $statement = mysqli_prepare($conn, "INSERT INTO colleges (name, code) VALUES (?, ?)");
    if (!$statement) {
        return false;
    }
    $code = $code === '' ? null : $code;
    mysqli_stmt_bind_param($statement, 'ss', $name, $code);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

function updateCollege($conn, $id, $name, $code)
{
    if (!mysqli_begin_transaction($conn)) {
        return false;
    }

    $statement = mysqli_prepare($conn, "SELECT name FROM colleges WHERE id = ? FOR UPDATE");
    if (!$statement) {
        mysqli_rollback($conn);
        return false;
    }
    $id = (int) $id;
    mysqli_stmt_bind_param($statement, 'i', $id);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        mysqli_rollback($conn);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $college = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);
    if (!$college) {
        mysqli_rollback($conn);
        return false;
    }

    $statement = mysqli_prepare($conn, "UPDATE colleges SET name = ?, code = ? WHERE id = ?");
    if (!$statement) {
        mysqli_rollback($conn);
        return false;
    }
    mysqli_stmt_bind_param($statement, 'ssi', $name, $code, $id);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    if (!$success) {
        mysqli_rollback($conn);
        return false;
    }

    if ($college['name'] !== $name) {
        foreach (['users', 'elections'] as $table) {
            $statement = mysqli_prepare($conn, "UPDATE $table SET department = ? WHERE department = ?");
            if (!$statement) {
                mysqli_rollback($conn);
                return false;
            }
            mysqli_stmt_bind_param($statement, 'ss', $name, $college['name']);
            $success = mysqli_stmt_execute($statement);
            mysqli_stmt_close($statement);
            if (!$success) {
                mysqli_rollback($conn);
                return false;
            }
        }
    }

    if (!mysqli_commit($conn)) {
        mysqli_rollback($conn);
        return false;
    }
    return true;
}

function deleteCollege($conn, $id)
{
    $id = (int) $id;
    $statement = mysqli_prepare($conn, "SELECT c.name,
        (SELECT COUNT(*) FROM users u WHERE u.department = c.name) AS user_count,
        (SELECT COUNT(*) FROM elections e WHERE e.department = c.name) AS election_count
        FROM colleges c WHERE c.id = ? LIMIT 1");
    if (!$statement) {
        return ['success' => false, 'message' => 'Unable to check department usage: ' . mysqli_error($conn)];
    }
    mysqli_stmt_bind_param($statement, 'i', $id);
    if (!mysqli_stmt_execute($statement)) {
        $message = mysqli_stmt_error($statement);
        mysqli_stmt_close($statement);
        return ['success' => false, 'message' => 'Unable to check department usage: ' . $message];
    }
    $result = mysqli_stmt_get_result($statement);
    $college = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);
    if (!$college) {
        return ['success' => false, 'message' => 'The selected department was not found.'];
    }

    $userCount = (int) $college['user_count'];
    $electionCount = (int) $college['election_count'];
    if ($userCount > 0 || $electionCount > 0) {
        return [
            'success' => false,
            'message' => "Cannot delete {$college['name']}: it is assigned to $userCount user(s) and $electionCount election(s). Reassign those records first."
        ];
    }

    $statement = mysqli_prepare($conn, "DELETE FROM colleges WHERE id = ?");
    if (!$statement) {
        return ['success' => false, 'message' => 'Unable to prepare department deletion: ' . mysqli_error($conn)];
    }
    mysqli_stmt_bind_param($statement, 'i', $id);
    $success = mysqli_stmt_execute($statement);
    $message = mysqli_stmt_error($statement);
    $deleted = mysqli_stmt_affected_rows($statement) === 1;
    mysqli_stmt_close($statement);
    if (!$success) {
        return ['success' => false, 'message' => 'Unable to delete department: ' . $message];
    }
    if (!$deleted) {
        return ['success' => false, 'message' => 'The selected department was not found.'];
    }
    return ['success' => true, 'message' => 'Department deleted successfully.'];
}

function isRegisteredCollege($conn, $name)
{
    $statement = mysqli_prepare($conn, "SELECT id FROM colleges WHERE name = ? LIMIT 1");
    if (!$statement) {
        return false;
    }
    mysqli_stmt_bind_param($statement, 's', $name);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $exists = $result && mysqli_num_rows($result) > 0;
    mysqli_stmt_close($statement);
    return $exists;
}
