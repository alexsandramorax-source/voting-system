<?php

function ensureProfileCorrectionRequestSchema($conn)
{
    return (bool) mysqli_query($conn, "CREATE TABLE IF NOT EXISTS profile_correction_requests (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        requested_student_id VARCHAR(50) NOT NULL,
        requested_firstname VARCHAR(100) NOT NULL,
        requested_middlename VARCHAR(100) NOT NULL DEFAULT '',
        requested_lastname VARCHAR(100) NOT NULL,
        requested_email VARCHAR(100) NOT NULL,
        requested_department VARCHAR(100) NOT NULL,
        requested_year_level VARCHAR(30) NULL DEFAULT NULL,
        message VARCHAR(1000) NOT NULL DEFAULT '',
        status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reviewed_by INT UNSIGNED NULL DEFAULT NULL,
        reviewed_at DATETIME NULL DEFAULT NULL,
        KEY idx_profile_request_status (status, created_at),
        KEY idx_profile_request_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function createProfileCorrectionRequest($conn, $userId, $profile, $message)
{
    $statement = mysqli_prepare($conn, "INSERT INTO profile_correction_requests
        (user_id, requested_student_id, requested_firstname, requested_middlename, requested_lastname,
         requested_email, requested_department, requested_year_level, message)
        VALUES (?, ?, ?, ?, ?, ?, ?, NULLIF(?, ''), ?)");
    if (!$statement) {
        return false;
    }

    $userId = (int) $userId;
    mysqli_stmt_bind_param(
        $statement,
        'issssssss',
        $userId,
        $profile['school_id'],
        $profile['firstname'],
        $profile['middlename'],
        $profile['lastname'],
        $profile['email'],
        $profile['department'],
        $profile['year_level'],
        $message
    );
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

function getProfileCorrectionRequests($conn)
{
    $result = mysqli_query($conn, "SELECT requests.*, users.school_id AS current_student_id,
            users.firstname AS current_firstname, users.middlename AS current_middlename,
            users.lastname AS current_lastname, users.email AS current_email,
            users.department AS current_department, users.year_level AS current_year_level
        FROM profile_correction_requests AS requests
        LEFT JOIN users ON users.id = requests.user_id
        ORDER BY (requests.status = 'pending') DESC, requests.created_at DESC");
    if (!$result) {
        return false;
    }
    $requests = [];
    while ($request = mysqli_fetch_assoc($result)) {
        $requests[] = $request;
    }
    return $requests;
}

function getStudentProfileCorrectionRequests($conn, $userId)
{
    $statement = mysqli_prepare($conn, "SELECT id, requested_student_id, requested_email,
            status, created_at, reviewed_at
        FROM profile_correction_requests
        WHERE user_id = ?
        ORDER BY created_at DESC");
    if (!$statement) {
        return false;
    }
    $userId = (int) $userId;
    mysqli_stmt_bind_param($statement, 'i', $userId);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    if (!$result) {
        mysqli_stmt_close($statement);
        return false;
    }
    $requests = [];
    while ($request = mysqli_fetch_assoc($result)) {
        $requests[] = $request;
    }
    mysqli_stmt_close($statement);
    return $requests;
}

function reviewProfileCorrectionRequest($conn, $requestId, $adminId, $decision, &$error = null)
{
    $error = '';
    if (!in_array($decision, ['approved', 'rejected'], true)) {
        $error = 'Choose either approve or reject.';
        return false;
    }
    if (!mysqli_begin_transaction($conn)) {
        $error = 'Unable to start the database transaction: ' . mysqli_error($conn);
        return false;
    }

    $requestId = (int) $requestId;
    $statement = mysqli_prepare($conn, "SELECT * FROM profile_correction_requests WHERE id = ? FOR UPDATE");
    if (!$statement) {
        $error = 'Unable to load the correction request: ' . mysqli_error($conn);
        mysqli_rollback($conn);
        return false;
    }
    mysqli_stmt_bind_param($statement, 'i', $requestId);
    if (!mysqli_stmt_execute($statement)) {
        $error = 'Unable to load the correction request: ' . mysqli_stmt_error($statement);
        mysqli_stmt_close($statement);
        mysqli_rollback($conn);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $request = $result ? mysqli_fetch_assoc($result) : false;
    mysqli_stmt_close($statement);
    if (!$request || $request['status'] !== 'pending') {
        $error = 'This request no longer exists or has already been reviewed.';
        mysqli_rollback($conn);
        return false;
    }

    if ($decision === 'approved') {
        $userId = (int) $request['user_id'];
        $student = mysqli_prepare($conn, "SELECT id FROM users WHERE id = ? AND role = 'student' FOR UPDATE");
        if (!$student) {
            $error = 'Unable to check the student account: ' . mysqli_error($conn);
            mysqli_rollback($conn);
            return false;
        }
        mysqli_stmt_bind_param($student, 'i', $userId);
        if (!mysqli_stmt_execute($student)) {
            $error = 'Unable to check the student account: ' . mysqli_stmt_error($student);
            mysqli_stmt_close($student);
            mysqli_rollback($conn);
            return false;
        }
        $studentResult = mysqli_stmt_get_result($student);
        $studentExists = $studentResult && mysqli_num_rows($studentResult) === 1;
        mysqli_stmt_close($student);
        if (!$studentExists) {
            $error = 'The student account no longer exists or is no longer a student account.';
            mysqli_rollback($conn);
            return false;
        }

        $duplicate = mysqli_prepare($conn, "SELECT id FROM users
            WHERE (school_id = ? OR email = ?) AND id <> ? LIMIT 1");
        if (!$duplicate) {
            $error = 'Unable to check Student ID and email conflicts: ' . mysqli_error($conn);
            mysqli_rollback($conn);
            return false;
        }
        mysqli_stmt_bind_param($duplicate, 'ssi', $request['requested_student_id'], $request['requested_email'], $userId);
        if (!mysqli_stmt_execute($duplicate)) {
            $error = 'Unable to check Student ID and email conflicts: ' . mysqli_stmt_error($duplicate);
            mysqli_stmt_close($duplicate);
            mysqli_rollback($conn);
            return false;
        }
        $duplicateResult = mysqli_stmt_get_result($duplicate);
        $hasDuplicate = $duplicateResult && mysqli_num_rows($duplicateResult) > 0;
        mysqli_stmt_close($duplicate);
        if ($hasDuplicate) {
            $error = 'The requested Student ID or email is already assigned to another account. Ask the student to correct the request.';
            mysqli_rollback($conn);
            return false;
        }

        $updateUser = mysqli_prepare($conn, "UPDATE users
            SET school_id = ?, firstname = ?, middlename = ?, lastname = ?, email = ?,
                department = ?, year_level = NULLIF(?, '')
            WHERE id = ? AND role = 'student'");
        if (!$updateUser) {
            $error = 'Unable to prepare the student account update: ' . mysqli_error($conn);
            mysqli_rollback($conn);
            return false;
        }
        mysqli_stmt_bind_param(
            $updateUser,
            'sssssssi',
            $request['requested_student_id'],
            $request['requested_firstname'],
            $request['requested_middlename'],
            $request['requested_lastname'],
            $request['requested_email'],
            $request['requested_department'],
            $request['requested_year_level'],
            $userId
        );
        $userUpdated = mysqli_stmt_execute($updateUser);
        if (!$userUpdated) {
            $error = 'Unable to update the student account: ' . mysqli_stmt_error($updateUser);
        }
        mysqli_stmt_close($updateUser);
        if (!$userUpdated) {
            mysqli_rollback($conn);
            return false;
        }

        $voterUpdated = syncVoterRegistryForUser($conn, $userId);
        if (!$voterUpdated) {
            $error = 'Unable to synchronize the voter registry: ' . mysqli_error($conn);
            mysqli_rollback($conn);
            return false;
        }
    }

    $review = mysqli_prepare($conn, "UPDATE profile_correction_requests
        SET status = ?, reviewed_by = ?, reviewed_at = NOW()
        WHERE id = ? AND status = 'pending'");
    if (!$review) {
        $error = 'Unable to prepare the review update: ' . mysqli_error($conn);
        mysqli_rollback($conn);
        return false;
    }
    $adminId = (int) $adminId;
    mysqli_stmt_bind_param($review, 'sii', $decision, $adminId, $requestId);
    $success = mysqli_stmt_execute($review);
    if (!$success) {
        $error = 'Unable to save the review decision: ' . mysqli_stmt_error($review);
    } elseif (mysqli_stmt_affected_rows($review) !== 1) {
        $error = 'The request was not pending when the review was saved.';
        $success = false;
    }
    mysqli_stmt_close($review);
    if (!$success) {
        mysqli_rollback($conn);
        return false;
    }
    if (!mysqli_commit($conn)) {
        $error = 'Unable to commit the review decision: ' . mysqli_error($conn);
        mysqli_rollback($conn);
        return false;
    }
    return true;
}
