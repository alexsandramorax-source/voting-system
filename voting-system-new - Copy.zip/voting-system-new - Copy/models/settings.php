<?php

function getDefaultAppSettings()
{
    return [
        'system_name' => 'SBO Voting System',
        'institution_name' => 'Student Body Organization',
        'support_email' => '',
        'default_election_duration_hours' => '24',
        'session_timeout_minutes' => '30',
        'minimum_password_length' => '8',
        'require_password_change' => '1'
    ];
}

function ensureAppSettingsSchema($conn)
{
    if (!mysqli_query($conn, "CREATE TABLE IF NOT EXISTS app_settings (
        setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
        setting_value VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")) {
        return false;
    }

    $statement = mysqli_prepare($conn, "INSERT IGNORE INTO app_settings (setting_key, setting_value) VALUES (?, ?)");
    if (!$statement) {
        return false;
    }
    foreach (getDefaultAppSettings() as $key => $value) {
        mysqli_stmt_bind_param($statement, 'ss', $key, $value);
        if (!mysqli_stmt_execute($statement)) {
            mysqli_stmt_close($statement);
            return false;
        }
    }
    mysqli_stmt_close($statement);
    return true;
}

function getAppSettings($conn)
{
    $settings = getDefaultAppSettings();
    $result = mysqli_query($conn, "SELECT setting_key, setting_value FROM app_settings");
    if (!$result) {
        return false;
    }
    while ($setting = mysqli_fetch_assoc($result)) {
        if (array_key_exists($setting['setting_key'], $settings)) {
            $settings[$setting['setting_key']] = $setting['setting_value'];
        }
    }
    return $settings;
}

function getAppSetting($conn, $key)
{
    $defaults = getDefaultAppSettings();
    if (!array_key_exists($key, $defaults)) {
        return false;
    }
    $statement = mysqli_prepare($conn, "SELECT setting_value FROM app_settings WHERE setting_key = ? LIMIT 1");
    if (!$statement) {
        return false;
    }
    mysqli_stmt_bind_param($statement, 's', $key);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $row = $result ? mysqli_fetch_assoc($result) : false;
    mysqli_stmt_close($statement);
    return $row ? $row['setting_value'] : $defaults[$key];
}

function saveAppSettings($conn, $settings)
{
    if (!mysqli_begin_transaction($conn)) {
        return false;
    }
    $statement = mysqli_prepare($conn, "INSERT INTO app_settings (setting_key, setting_value)
        VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    if (!$statement) {
        mysqli_rollback($conn);
        return false;
    }
    foreach ($settings as $key => $value) {
        mysqli_stmt_bind_param($statement, 'ss', $key, $value);
        if (!mysqli_stmt_execute($statement)) {
            mysqli_stmt_close($statement);
            mysqli_rollback($conn);
            return false;
        }
    }
    mysqli_stmt_close($statement);
    if (!mysqli_commit($conn)) {
        mysqli_rollback($conn);
        return false;
    }
    return true;
}
