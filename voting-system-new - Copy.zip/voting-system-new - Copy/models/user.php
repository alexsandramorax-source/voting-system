<?php
require_once __DIR__ . '/settings.php';

// Fetch a single user by email and password for login
function getUser($conn, $email, $password)
{
    $statement = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ? LIMIT 1");
    if (!$statement) {
        return false;
    }

    mysqli_stmt_bind_param($statement, 's', $email);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $user = $result ? mysqli_fetch_assoc($result) : false;
    mysqli_stmt_close($statement);
    if (!$user) {
        return false;
    }

    $storedPassword = (string) $user['password'];
    $passwordInfo = password_get_info($storedPassword);
    $isPasswordHash = $passwordInfo['algoName'] !== 'unknown';
    $passwordIsValid = $isPasswordHash
        ? password_verify($password, $storedPassword)
        : hash_equals($storedPassword, $password);
    if (!$passwordIsValid) {
        return false;
    }

    if (!$isPasswordHash || password_needs_rehash($storedPassword, PASSWORD_DEFAULT)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $upgrade = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE id = ? AND password = ?");
        if (!$newHash || !$upgrade) {
            return false;
        }
        $userId = (int) $user['id'];
        mysqli_stmt_bind_param($upgrade, 'sis', $newHash, $userId, $storedPassword);
        $success = mysqli_stmt_execute($upgrade);
        mysqli_stmt_close($upgrade);
        if (!$success) {
            return false;
        }
        $user['password'] = $newHash;
    }
    return $user;
}

// Fetch a single user by their ID used to reload fresh session data
function getUserById($conn, $user_id)
{
    $query  = "SELECT * FROM users WHERE id = $user_id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }

    return false;
}

// Mark the user as online, store their session ID, and stamp the activity time
function setSession($conn, $user_id, $current_session)
{
    $statement = mysqli_prepare($conn, "UPDATE users
        SET is_online = 1, session_id = ?, last_activity = NOW()
        WHERE id = ?");
    if (!$statement) {
        return false;
    }
    $user_id = (int) $user_id;
    mysqli_stmt_bind_param($statement, 'si', $current_session, $user_id);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Set the user as offline and clear their session when they log out
function setUserOffline($conn, $user_id, $expected_session = null)
{
    if ($expected_session !== null) {
        $statement = mysqli_prepare($conn, "UPDATE users
            SET is_online = 0, session_id = NULL, last_activity = NULL
            WHERE id = ? AND session_id = ?");
        if (!$statement) {
            return false;
        }
        $user_id = (int) $user_id;
        mysqli_stmt_bind_param($statement, 'is', $user_id, $expected_session);
    } else {
        $statement = mysqli_prepare($conn, "UPDATE users
            SET is_online = 0, session_id = NULL, last_activity = NULL WHERE id = ?");
        if (!$statement) {
            return false;
        }
        $user_id = (int) $user_id;
        mysqli_stmt_bind_param($statement, 'i', $user_id);
    }
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Call this on every page load to keep the activity timestamp fresh
function refreshActivity($conn, $user_id)
{
    $query = "UPDATE users SET last_activity = NOW() WHERE id = '$user_id'";
    mysqli_query($conn, $query);
}

// Check if a user has an active session on another device.
// A session is only considered truly active if last_activity
// was within the last 30 minutes  handles closed tab or forgotten sessions.
function isSessionActiveElsewhere($conn, $user_id, $current_session)
{
    $timeoutMinutes = filter_var(getAppSetting($conn, 'session_timeout_minutes'), FILTER_VALIDATE_INT);
    if ($timeoutMinutes === false || $timeoutMinutes < 5 || $timeoutMinutes > 1440) {
        return true;
    }
    $statement = mysqli_prepare($conn, "SELECT session_id, last_activity,
        (last_activity >= DATE_SUB(NOW(), INTERVAL $timeoutMinutes MINUTE)) AS is_recent
        FROM users WHERE id = ?");
    if (!$statement) {
        return false;
    }
    $user_id = (int) $user_id;
    mysqli_stmt_bind_param($statement, 'i', $user_id);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);

    if (!$result || mysqli_num_rows($result) === 0) {
        mysqli_stmt_close($statement);
        return false;
    }

    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($statement);

    // No stored session not active anywhere
    if (empty($row['session_id'])) {
        return false;
    }

    // Same device/browser not a conflict
    if ($row['session_id'] === $current_session) {
        return false;
    }

    // Different session ID found only block if they were active recently
    // Within 30 minutes Anything older means the tab was just closed/forgotten.
    if ((int) $row['is_recent'] !== 1) {
        setUserOffline($conn, $user_id, $row['session_id']);
        return false;
    }

    return true;
}

// Return all users except the currently logged-in admin
function getUserAll($conn, $current_user_id)
{
    $current_user_id = (int) $current_user_id;
    $query  = "SELECT * FROM users WHERE id != $current_user_id ORDER BY lastname, firstname, email";
    $result = mysqli_query($conn, $query);

    $users = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $users[] = $row;
        }
    }

    return $users;
}

function getStudents($conn)
{
    $result = mysqli_query($conn, "SELECT id, school_id, firstname, middlename, lastname, email, department, year_level
        FROM users WHERE role = 'student' AND TRIM(firstname) <> '' AND TRIM(lastname) <> ''
        ORDER BY lastname, firstname, school_id");
    $students = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $students[] = $row;
        }
    }
    return $students;
}

function getStudentById($conn, $student_id)
{
    $student_id = filter_var($student_id, FILTER_VALIDATE_INT);
    if ($student_id === false || $student_id < 1) {
        return false;
    }
    $statement = mysqli_prepare($conn, "SELECT id, school_id, firstname, middlename, lastname, email, department, year_level
        FROM users
        WHERE id = ? AND role = 'student' AND TRIM(firstname) <> '' AND TRIM(lastname) <> ''
        LIMIT 1");
    if (!$statement) {
        return false;
    }
    mysqli_stmt_bind_param($statement, 'i', $student_id);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $student = mysqli_fetch_assoc($result);
    mysqli_stmt_close($statement);
    return $student ?: false;
}

function ensureVoterRegistrySchema($conn)
{
    if (!mysqli_query($conn, "CREATE TABLE IF NOT EXISTS voters (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        Student_id VARCHAR(50) NOT NULL,
        firstname VARCHAR(100) NOT NULL,
        middlename VARCHAR(100) NOT NULL DEFAULT '',
        lastname VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        department VARCHAR(100) NOT NULL,
        year_level VARCHAR(30) NULL DEFAULT NULL,
        user_id INT(6) UNSIGNED NULL DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_voter_user (user_id),
        KEY idx_voter_student_id (Student_id),
        KEY idx_voter_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")) {
        return false;
    }

    return (bool) mysqli_query($conn, "INSERT INTO voters
        (Student_id, firstname, middlename, lastname, email, department, year_level, user_id)
        SELECT school_id, firstname, middlename, lastname, email, department, year_level, id
        FROM users
        WHERE role = 'student'
        ON DUPLICATE KEY UPDATE
            Student_id = VALUES(Student_id),
            firstname = VALUES(firstname),
            middlename = VALUES(middlename),
            lastname = VALUES(lastname),
            email = VALUES(email),
            department = VALUES(department),
            year_level = VALUES(year_level)");
}

function syncVoterRegistryForUser($conn, $user_id)
{
    $statement = mysqli_prepare($conn, "SELECT id, school_id, firstname, middlename, lastname,
        email, department, year_level, role FROM users WHERE id = ? LIMIT 1");
    if (!$statement) {
        return false;
    }
    $user_id = (int) $user_id;
    mysqli_stmt_bind_param($statement, 'i', $user_id);
    if (!mysqli_stmt_execute($statement)) {
        mysqli_stmt_close($statement);
        return false;
    }
    $result = mysqli_stmt_get_result($statement);
    $user = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);
    if (!$user) {
        return false;
    }

    if ($user['role'] !== 'student') {
        $statement = mysqli_prepare($conn, "DELETE FROM voters WHERE user_id = ?");
        if (!$statement) {
            return false;
        }
        mysqli_stmt_bind_param($statement, 'i', $user_id);
    } else {
        $statement = mysqli_prepare($conn, "INSERT INTO voters
            (Student_id, firstname, middlename, lastname, email, department, year_level, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                Student_id = VALUES(Student_id),
                firstname = VALUES(firstname),
                middlename = VALUES(middlename),
                lastname = VALUES(lastname),
                email = VALUES(email),
                department = VALUES(department),
                year_level = VALUES(year_level)");
        if (!$statement) {
            return false;
        }
        mysqli_stmt_bind_param(
            $statement,
            'sssssssi',
            $user['school_id'],
            $user['firstname'],
            $user['middlename'],
            $user['lastname'],
            $user['email'],
            $user['department'],
            $user['year_level'],
            $user_id
        );
    }

    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

function getVoterRegistry($conn)
{
    $result = mysqli_query($conn, "SELECT Student_id, firstname, middlename, lastname,
        email, department, year_level
        FROM voters
        ORDER BY lastname, firstname, Student_id");
    if (!$result) {
        return false;
    }
    $voters = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $voters[] = $row;
    }
    return $voters;
}

function generateDefaultPasswordsForVoters($conn)
{
    if (!mysqli_begin_transaction($conn)) {
        return ['error' => 'Unable to start password generation: ' . mysqli_error($conn)];
    }

    $select = null;
    $update = null;
    $credentials = [];
    try {
        $select = mysqli_prepare($conn, "SELECT id, school_id, firstname, middlename, lastname, email, department, year_level
            FROM users WHERE role = 'student' ORDER BY lastname, firstname, school_id FOR UPDATE");
        $update = mysqli_prepare($conn, "UPDATE users
            SET password = ?, is_new = 1, is_online = 0, session_id = NULL, last_activity = NULL
            WHERE id = ? AND role = 'student'");
        if (!$select || !$update) {
            throw new RuntimeException('Unable to prepare password generation: ' . mysqli_error($conn));
        }
        if (!mysqli_stmt_execute($select)) {
            throw new RuntimeException('Unable to load voter accounts: ' . mysqli_stmt_error($select));
        }
        $result = mysqli_stmt_get_result($select);
        if (!$result) {
            throw new RuntimeException('Unable to read voter accounts: ' . mysqli_stmt_error($select));
        }

        while ($voter = mysqli_fetch_assoc($result)) {
            $password = '123456';
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            if ($passwordHash === false) {
                throw new RuntimeException('Unable to secure a generated voter password.');
            }
            $userId = (int) $voter['id'];
            mysqli_stmt_bind_param($update, 'si', $passwordHash, $userId);
            if (!mysqli_stmt_execute($update) || mysqli_stmt_affected_rows($update) !== 1) {
                throw new RuntimeException('Unable to update the password for voter account ' . $userId . ': ' . mysqli_stmt_error($update));
            }
            $credentials[] = [
                'Student_id' => $voter['school_id'],
                'firstname' => $voter['firstname'],
                'middlename' => $voter['middlename'],
                'lastname' => $voter['lastname'],
                'email' => $voter['email'],
                'department' => $voter['department'],
                'year_level' => $voter['year_level'] ?? '',
                'password' => $password
            ];
        }

        mysqli_stmt_close($select);
        $select = null;
        mysqli_stmt_close($update);
        $update = null;
        if (!mysqli_commit($conn)) {
            throw new RuntimeException('Unable to save generated voter passwords: ' . mysqli_error($conn));
        }
        return ['credentials' => $credentials, 'generated_count' => count($credentials)];
    } catch (Throwable $exception) {
        if ($select) {
            mysqli_stmt_close($select);
        }
        if ($update) {
            mysqli_stmt_close($update);
        }
        mysqli_rollback($conn);
        return ['error' => $exception->getMessage()];
    }
}

function readVoterImportFile($filePath, $originalName = '')
{
    $extension = strtolower(pathinfo($originalName !== '' ? $originalName : $filePath, PATHINFO_EXTENSION));
    if ($extension === 'csv') {
        $file = fopen($filePath, 'r');
        if ($file === false) {
            return ['error' => 'The uploaded CSV file could not be read.'];
        }
        $header = fgetcsv($file);
        if ($header === false) {
            fclose($file);
            return ['error' => 'The uploaded CSV file is empty.'];
        }
        $rows = [];
        while (($row = fgetcsv($file)) !== false) {
            $rows[] = $row;
        }
        fclose($file);
        return ['header' => $header, 'rows' => $rows];
    }

    if ($extension !== 'xlsx') {
        return ['error' => 'Upload an Excel .xlsx file or a .csv file.'];
    }
    if (!class_exists('ZipArchive') || !function_exists('simplexml_load_string')) {
        return ['error' => 'Excel .xlsx uploads are not supported by the current PHP installation. Upload a .csv file instead.'];
    }

    $archive = new ZipArchive();
    if ($archive->open($filePath) !== true) {
        return ['error' => 'The Excel file is invalid or could not be opened.'];
    }

    try {
        $mainNamespace = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
        $officeNamespace = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
        $packageNamespace = 'http://schemas.openxmlformats.org/package/2006/relationships';
        $workbookContent = $archive->getFromName('xl/workbook.xml');
        $relationshipContent = $archive->getFromName('xl/_rels/workbook.xml.rels');
        if ($workbookContent === false || $relationshipContent === false) {
            return ['error' => 'The Excel workbook is missing its worksheet information.'];
        }

        $workbook = simplexml_load_string($workbookContent, 'SimpleXMLElement', LIBXML_NONET);
        $relationships = simplexml_load_string($relationshipContent, 'SimpleXMLElement', LIBXML_NONET);
        if ($workbook === false || $relationships === false) {
            return ['error' => 'The Excel workbook contains invalid XML.'];
        }
        $workbook->registerXPathNamespace('m', $mainNamespace);
        $sheets = $workbook->xpath('//m:sheets/m:sheet');
        if (!$sheets || !isset($sheets[0])) {
            return ['error' => 'The Excel workbook does not contain a worksheet.'];
        }
        $sheetAttributes = $sheets[0]->attributes($officeNamespace);
        $relationshipId = (string) ($sheetAttributes['id'] ?? '');

        $relationships->registerXPathNamespace('p', $packageNamespace);
        $relationshipNodes = $relationships->xpath('//p:Relationship');
        $target = '';
        foreach ($relationshipNodes ?: [] as $relationship) {
            if ((string) $relationship['Id'] === $relationshipId) {
                $target = (string) $relationship['Target'];
                break;
            }
        }
        if ($target === '') {
            return ['error' => 'The first Excel worksheet could not be located.'];
        }
        $sheetPath = ltrim(strpos($target, '/') === 0 ? $target : 'xl/' . $target, '/');
        if (strpos($sheetPath, '..') !== false) {
            return ['error' => 'The Excel workbook contains an invalid worksheet path.'];
        }
        $sheetContent = $archive->getFromName($sheetPath);
        if ($sheetContent === false) {
            return ['error' => 'The first Excel worksheet could not be read.'];
        }
        $sheet = simplexml_load_string($sheetContent, 'SimpleXMLElement', LIBXML_NONET);
        if ($sheet === false) {
            return ['error' => 'The first Excel worksheet contains invalid XML.'];
        }
        $sheet->registerXPathNamespace('m', $mainNamespace);

        $sharedStrings = [];
        $sharedContent = $archive->getFromName('xl/sharedStrings.xml');
        if ($sharedContent !== false) {
            $sharedXml = simplexml_load_string($sharedContent, 'SimpleXMLElement', LIBXML_NONET);
            if ($sharedXml === false) {
                return ['error' => 'The Excel workbook contains invalid shared text data.'];
            }
            $sharedXml->registerXPathNamespace('m', $mainNamespace);
            foreach ($sharedXml->xpath('//m:si') as $sharedItem) {
                $sharedItem->registerXPathNamespace('m', $mainNamespace);
                $text = '';
                foreach ($sharedItem->xpath('.//m:t') as $textNode) {
                    $text .= (string) $textNode;
                }
                $sharedStrings[] = $text;
            }
        }

        $tableRows = [];
        foreach ($sheet->xpath('//m:sheetData/m:row') as $xmlRow) {
            $xmlRow->registerXPathNamespace('m', $mainNamespace);
            $values = [];
            foreach ($xmlRow->xpath('./m:c') as $cell) {
                $cell->registerXPathNamespace('m', $mainNamespace);
                $attributes = $cell->attributes();
                $reference = (string) ($attributes['r'] ?? '');
                if (!preg_match('/^([A-Z]+)/i', $reference, $columnMatch)) {
                    continue;
                }
                $columnNumber = 0;
                foreach (str_split(strtoupper($columnMatch[1])) as $letter) {
                    $columnNumber = ($columnNumber * 26) + ord($letter) - 64;
                }
                $cellType = (string) ($attributes['t'] ?? '');
                $valueNodes = $cell->xpath('./m:v');
                $value = $valueNodes && isset($valueNodes[0]) ? (string) $valueNodes[0] : '';
                if ($cellType === 's') {
                    $value = $sharedStrings[(int) $value] ?? '';
                } elseif ($cellType === 'inlineStr') {
                    $textNodes = $cell->xpath('.//m:is//m:t');
                    $value = '';
                    foreach ($textNodes as $textNode) {
                        $value .= (string) $textNode;
                    }
                }
                $values[$columnNumber - 1] = $value;
            }
            if ($values !== []) {
                ksort($values);
                $lastColumn = max(array_keys($values));
                $tableRows[] = array_replace(array_fill(0, $lastColumn + 1, ''), $values);
            } else {
                $tableRows[] = [];
            }
        }
        if ($tableRows === []) {
            return ['error' => 'The first Excel worksheet is empty.'];
        }
        $header = array_shift($tableRows);
        return ['header' => $header, 'rows' => $tableRows];
    } finally {
        $archive->close();
    }
}

function importVotersFromCsv($conn, $filePath, $validColleges, $originalName = '')
{
    if (!ensureVoterRegistrySchema($conn)) {
        return ['error' => 'Unable to prepare the voter registry table: ' . mysqli_error($conn)];
    }

    $spreadsheet = readVoterImportFile($filePath, $originalName);
    if (isset($spreadsheet['error'])) {
        return $spreadsheet;
    }
    $header = $spreadsheet['header'];
    if (!is_array($header) || $header === []) {
        return ['error' => 'The spreadsheet must have a header row in its first row.'];
    }
    $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]);
    $header = array_map(function ($value) {
        $normalized = strtolower(trim((string) $value));
        $normalized = preg_replace('/[\s-]+/', '_', $normalized);
        return $normalized === 'school_id' ? 'student_id' : $normalized;
    }, $header);
    $required = ['student_id', 'firstname', 'lastname', 'email', 'department'];
    $indexes = [];
    foreach ($required as $column) {
        $index = array_search($column, $header, true);
        if ($index === false) {
            return ['error' => 'The spreadsheet must include these headers: Student_id, firstname, lastname, email, department.'];
        }
        $indexes[$column] = $index;
    }
    $nonEmptyHeaders = array_values(array_filter($header, function ($value) {
        return $value !== '';
    }));
    if (count(array_unique($nonEmptyHeaders)) !== count($nonEmptyHeaders)) {
        return ['error' => 'The spreadsheet contains duplicate column headers. Make sure each header appears only once.'];
    }
    $middleNameIndex = array_search('middlename', $header, true);
    if ($middleNameIndex === false) {
        $middleNameIndex = array_search('middle_name', $header, true);
    }
    $yearLevelIndex = array_search('year_level', $header, true);

    $validCollegeNames = array_column($validColleges, 'name');
    $credentials = [];
    $errors = [];
    $addedCount = 0;
    $updatedCount = 0;
    $line = 1;
    $userLookup = null;
    $voterLookup = null;
    $insertUser = null;
    $updateUser = null;
    $updateVoter = null;

    if (!mysqli_begin_transaction($conn)) {
        return ['error' => 'Unable to start the voter import transaction: ' . mysqli_error($conn)];
    }
    try {
        $userLookup = mysqli_prepare($conn, "SELECT id, role FROM users WHERE school_id = ? OR email = ? FOR UPDATE");
        $voterLookup = mysqli_prepare($conn, "SELECT id, user_id FROM voters WHERE Student_id = ? OR email = ? FOR UPDATE");
        $insertUser = mysqli_prepare($conn, "INSERT INTO users
            (school_id, firstname, middlename, lastname, email, password, role, department, year_level, is_new)
            VALUES (?, ?, ?, ?, ?, ?, 'student', ?, ?, 1)");
        $updateUser = mysqli_prepare($conn, "UPDATE users
            SET school_id = ?, firstname = ?, middlename = ?, lastname = ?, email = ?, department = ?, year_level = ?
            WHERE id = ? AND role = 'student'");
        $updateVoter = mysqli_prepare($conn, "UPDATE voters
            SET Student_id = ?, firstname = ?, middlename = ?, lastname = ?, email = ?, department = ?, year_level = ?, user_id = ?
            WHERE id = ?");
        if (!$userLookup || !$voterLookup || !$insertUser || !$updateUser || !$updateVoter) {
            throw new RuntimeException('Unable to prepare voter import queries: ' . mysqli_error($conn));
        }

        foreach ($spreadsheet['rows'] as $row) {
            $line++;
            if (count(array_filter($row, function ($value) {
                return trim((string) $value) !== '';
            })) === 0) {
                continue;
            }

            $voter = [];
            foreach ($indexes as $column => $index) {
                $voter[$column] = trim((string) ($row[$index] ?? ''));
            }
            $voter['middlename'] = $middleNameIndex === false ? '' : trim((string) ($row[$middleNameIndex] ?? ''));
            $voter['year_level'] = $yearLevelIndex === false ? '' : trim((string) ($row[$yearLevelIndex] ?? ''));
            if (in_array('', array_intersect_key($voter, array_flip($required)), true)
                || !filter_var($voter['email'], FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Row $line: required values are missing or the email is invalid.";
                continue;
            }
            if (strlen($voter['student_id']) > 50 || strlen($voter['firstname']) > 100
                || strlen($voter['middlename']) > 100 || strlen($voter['lastname']) > 100
                || strlen($voter['email']) > 100 || strlen($voter['department']) > 100
                || strlen($voter['year_level']) > 30) {
                $errors[] = "Row $line: a value exceeds its maximum length (Student_id: 50, names/email/department: 100, year level: 30 characters).";
                continue;
            }
            if (!in_array($voter['department'], $validCollegeNames, true)) {
                $errors[] = "Row $line: college/department '{$voter['department']}' is not registered.";
                continue;
            }

            mysqli_stmt_bind_param($userLookup, 'ss', $voter['student_id'], $voter['email']);
            if (!mysqli_stmt_execute($userLookup)) {
                throw new RuntimeException('Unable to find an existing student account: ' . mysqli_stmt_error($userLookup));
            }
            $userResult = mysqli_stmt_get_result($userLookup);
            if (!$userResult) {
                throw new RuntimeException('Unable to read existing student accounts: ' . mysqli_stmt_error($userLookup));
            }
            $matchedUsers = [];
            while ($matchedUser = mysqli_fetch_assoc($userResult)) {
                $matchedUsers[(int) $matchedUser['id']] = $matchedUser;
            }

            mysqli_stmt_bind_param($voterLookup, 'ss', $voter['student_id'], $voter['email']);
            if (!mysqli_stmt_execute($voterLookup)) {
                throw new RuntimeException('Unable to find an existing voter registry record: ' . mysqli_stmt_error($voterLookup));
            }
            $voterResult = mysqli_stmt_get_result($voterLookup);
            if (!$voterResult) {
                throw new RuntimeException('Unable to read existing voter registry records: ' . mysqli_stmt_error($voterLookup));
            }
            $matchedVoters = [];
            while ($matchedVoter = mysqli_fetch_assoc($voterResult)) {
                $matchedVoters[(int) $matchedVoter['id']] = $matchedVoter;
            }

            $identities = [];
            foreach ($matchedUsers as $matchedUser) {
                $identities['user:' . (int) $matchedUser['id'] ] = [
                    'user_id' => (int) $matchedUser['id'],
                    'role' => $matchedUser['role'],
                    'voter_id' => null
                ];
            }
            foreach ($matchedVoters as $matchedVoter) {
                $linkedUserId = $matchedVoter['user_id'] === null ? 0 : (int) $matchedVoter['user_id'];
                $identityKey = $linkedUserId > 0 ? 'user:' . $linkedUserId : 'voter:' . (int) $matchedVoter['id'];
                if (!isset($identities[$identityKey])) {
                    $identities[$identityKey] = [
                        'user_id' => $linkedUserId,
                        'role' => null,
                        'voter_id' => (int) $matchedVoter['id']
                    ];
                } elseif ($identities[$identityKey]['voter_id'] === null) {
                    $identities[$identityKey]['voter_id'] = (int) $matchedVoter['id'];
                }
            }
            if (count($identities) > 1) {
                $errors[] = "Row $line: Student_id and email match different existing records; resolve the conflict before importing.";
                continue;
            }

            $identity = $identities === [] ? null : reset($identities);
            if ($identity !== null && $identity['role'] !== null && $identity['role'] !== 'student') {
                $errors[] = "Row $line: Student_id or email belongs to a non-student account; voter was not updated.";
                continue;
            }

            if ($identity === null || $identity['user_id'] === 0) {
                $password = '123456';
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                if ($passwordHash === false) {
                    throw new RuntimeException('Unable to secure the generated password for row ' . $line . '.');
                }
                mysqli_stmt_bind_param(
                    $insertUser,
                    'ssssssss',
                    $voter['student_id'],
                    $voter['firstname'],
                    $voter['middlename'],
                    $voter['lastname'],
                    $voter['email'],
                    $passwordHash,
                    $voter['department'],
                    $voter['year_level']
                );
                if (!mysqli_stmt_execute($insertUser)) {
                    throw new RuntimeException('Unable to import voter on row ' . $line . ': ' . mysqli_stmt_error($insertUser));
                }
                $userId = (int) mysqli_insert_id($conn);
                $credentials[] = [
                    'Student_id' => $voter['student_id'],
                    'firstname' => $voter['firstname'],
                    'middlename' => $voter['middlename'],
                    'lastname' => $voter['lastname'],
                    'email' => $voter['email'],
                    'department' => $voter['department'],
                    'year_level' => $voter['year_level'],
                    'password' => $password
                ];
                $addedCount++;
            } else {
                $userId = $identity['user_id'];
                mysqli_stmt_bind_param(
                    $updateUser,
                    'sssssssi',
                    $voter['student_id'],
                    $voter['firstname'],
                    $voter['middlename'],
                    $voter['lastname'],
                    $voter['email'],
                    $voter['department'],
                    $voter['year_level'],
                    $userId
                );
                if (!mysqli_stmt_execute($updateUser)) {
                    throw new RuntimeException('Unable to update voter account on row ' . $line . ': ' . mysqli_stmt_error($updateUser));
                }
                if (mysqli_stmt_affected_rows($updateUser) === 0 && mysqli_stmt_errno($updateUser) !== 0) {
                    throw new RuntimeException('Unable to update voter account on row ' . $line . ': ' . mysqli_stmt_error($updateUser));
                }
                $updatedCount++;
            }

            if ($identity !== null && $identity['voter_id'] !== null) {
                $voterId = $identity['voter_id'];
                mysqli_stmt_bind_param(
                    $updateVoter,
                    'sssssssii',
                    $voter['student_id'],
                    $voter['firstname'],
                    $voter['middlename'],
                    $voter['lastname'],
                    $voter['email'],
                    $voter['department'],
                    $voter['year_level'],
                    $userId,
                    $voterId
                );
                if (!mysqli_stmt_execute($updateVoter)) {
                    throw new RuntimeException('Unable to update voter registry row ' . $line . ': ' . mysqli_stmt_error($updateVoter));
                }
            } elseif (!syncVoterRegistryForUser($conn, $userId)) {
                throw new RuntimeException('Unable to synchronize voter registry row ' . $line . ': ' . mysqli_error($conn));
            }
        }

        foreach ([$userLookup, $voterLookup, $insertUser, $updateUser, $updateVoter] as $statement) {
            mysqli_stmt_close($statement);
        }
        $userLookup = $voterLookup = $insertUser = $updateUser = $updateVoter = null;
        if (!mysqli_commit($conn)) {
            throw new RuntimeException('Unable to commit voter import: ' . mysqli_error($conn));
        }
    } catch (Throwable $exception) {
        foreach ([$userLookup, $voterLookup, $insertUser, $updateUser, $updateVoter] as $statement) {
            if ($statement) {
                mysqli_stmt_close($statement);
            }
        }
        mysqli_rollback($conn);
        return ['error' => $exception->getMessage()];
    }

    return [
        'credentials' => $credentials,
        'errors' => $errors,
        'added_count' => $addedCount,
        'updated_count' => $updatedCount
    ];
}

// Update the password and flip is_new to 0 after first login
function updateUserPassword($conn, $user_id, $new_password)
{
    $passwordHash = password_hash($new_password, PASSWORD_DEFAULT);
    if ($passwordHash === false) {
        return false;
    }
    $statement = mysqli_prepare($conn, "UPDATE users SET password = ?, is_new = 0 WHERE id = ?");
    if (!$statement) {
        return false;
    }
    $user_id = (int) $user_id;
    mysqli_stmt_bind_param($statement, 'si', $passwordHash, $user_id);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    return $success;
}

// Write an action to the audit_logs table for traceability
function logAction($conn, $admin_id, $action, $details)
{
    $admin_id = (int) $admin_id;
    $query    = "INSERT INTO audit_logs (admin_id, action, details) VALUES ($admin_id, '$action', '$details')";
    mysqli_query($conn, $query);
}

// Insert a new user now includes firstname, lastname, and department
function addUser($conn, $school_id, $firstname, $middlename, $lastname, $email, $password, $role, $department, $year_level = '')
{
    if (!mysqli_begin_transaction($conn)) {
        return false;
    }
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    if ($passwordHash === false) {
        mysqli_rollback($conn);
        return false;
    }
    $statement = mysqli_prepare($conn, "INSERT INTO users
        (school_id, firstname, middlename, lastname, email, password, role, department, year_level, is_new)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
    if (!$statement) {
        mysqli_rollback($conn);
        return false;
    }
    mysqli_stmt_bind_param($statement, 'sssssssss', $school_id, $firstname, $middlename, $lastname, $email, $passwordHash, $role, $department, $year_level);
    $success = mysqli_stmt_execute($statement);
    $user_id = $success ? (int) mysqli_insert_id($conn) : 0;
    mysqli_stmt_close($statement);
    if (!$success || !syncVoterRegistryForUser($conn, $user_id) || !mysqli_commit($conn)) {
        mysqli_rollback($conn);
        return false;
    }
    return true;
}

// Update an existing user now includes firstname, lastname, and department
function updateUser($conn, $id, $school_id, $firstname, $middlename, $lastname, $email, $password, $role, $department, $year_level = '')
{
    if (!mysqli_begin_transaction($conn)) {
        return false;
    }
    if (!empty($password)) {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        if ($passwordHash === false) {
            mysqli_rollback($conn);
            return false;
        }
        $statement = mysqli_prepare($conn, "UPDATE users
            SET school_id = ?, firstname = ?, middlename = ?, lastname = ?, email = ?, role = ?, department = ?, year_level = ?, password = ?, is_new = 1
            WHERE id = ?");
        if (!$statement) {
            mysqli_rollback($conn);
            return false;
        }
        $id = (int) $id;
        mysqli_stmt_bind_param($statement, 'sssssssssi', $school_id, $firstname, $middlename, $lastname, $email, $role, $department, $year_level, $passwordHash, $id);
    } else {
        $statement = mysqli_prepare($conn, "UPDATE users
            SET school_id = ?, firstname = ?, middlename = ?, lastname = ?, email = ?, role = ?, department = ?, year_level = ?
            WHERE id = ?");
        if (!$statement) {
            mysqli_rollback($conn);
            return false;
        }
        $id = (int) $id;
        mysqli_stmt_bind_param($statement, 'ssssssssi', $school_id, $firstname, $middlename, $lastname, $email, $role, $department, $year_level, $id);
    }
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    if (!$success || !syncVoterRegistryForUser($conn, $id) || !mysqli_commit($conn)) {
        mysqli_rollback($conn);
        return false;
    }
    return true;
}

// Remove a user record permanently
function deleteUser($conn, $id)
{
    if (!mysqli_begin_transaction($conn)) {
        return false;
    }
    $id = (int) $id;
    $statement = mysqli_prepare($conn, "DELETE FROM voters WHERE user_id = ?");
    if (!$statement) {
        mysqli_rollback($conn);
        return false;
    }
    mysqli_stmt_bind_param($statement, 'i', $id);
    $success = mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
    if (!$success) {
        mysqli_rollback($conn);
        return false;
    }
    $statement = mysqli_prepare($conn, "DELETE FROM users WHERE id = ?");
    if (!$statement) {
        mysqli_rollback($conn);
        return false;
    }
    mysqli_stmt_bind_param($statement, 'i', $id);
    $success = mysqli_stmt_execute($statement) && mysqli_stmt_affected_rows($statement) === 1;
    mysqli_stmt_close($statement);
    if (!$success || !mysqli_commit($conn)) {
        mysqli_rollback($conn);
        return false;
    }
    return true;
}